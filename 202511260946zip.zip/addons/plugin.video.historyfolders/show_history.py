import sys
import datetime
import xbmcgui
import xbmcplugin
from add import get_history

def show_history():
    history = get_history()
    handle = int(sys.argv[1])

    for entry in history:
        li = xbmcgui.ListItem(label=entry["label"])

        # Thời gian mở
        timestamp = entry.get("time", 0)
        if timestamp:
            dt = datetime.datetime.fromtimestamp(timestamp)
            time_str = dt.strftime("%H:%M %d/%m")
        else:
            time_str = ""

        # Label2: sub_label + thời gian
        sub_label = entry.get("sub_label", "")
        parts = [sub_label] if sub_label else []
        if time_str:
            parts.append(time_str)
        li.setLabel2(" | ".join(parts))

        li.setInfo("video", {"title": entry["label"]})
        li.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=entry["path"],
            listitem=li,
            isFolder=True
        )

    xbmcplugin.endOfDirectory(handle)
