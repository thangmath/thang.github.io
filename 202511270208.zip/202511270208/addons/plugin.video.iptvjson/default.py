# -*- coding: utf-8 -*-
import sys
import json
from urllib import request, parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import time
import os
import re
import random

# ===== Biến môi trường Kodi =====
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
args = dict(parse.parse_qsl(sys.argv[2][1:]))
ADDON_GLOBAL_CATEGORY = "IPTVJSON"

# Danh sách preset nguồn JSON (tên, URL cơ sở)
DEFAULT_REMOTE_URL = "http://iptv.cameraddns.net/kodi/kodi.json"
URL_DS_NGUON_REMOTE = "http://iptv.cameraddns.net/kodi/kodi.json"
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP1A.241212) AppleWebKit/605.1.15 (KHTML, like Gecko) Dart/3.9 (dart:io) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
IMAGE_GENERATOR_URL = "https://iptv.cameraddns.net/kodi/svg/image_generator.php"
IMAGE_GENERATOR_SEARCH_RESULT = "https://iptv.cameraddns.net/kodi/svg/image_search_result.php"
IMAGE_GENERATOR_NEXTPAGE = "https://iptv.cameraddns.net/kodi/svg/image_nextpage.php"
KT_SEARCH = 50
SET_SIZE_KEY = 50
_DANH_SACH_NGUON_CACHE = None

DANH_SACH_NGUON_MACDINH = [
    ("kkphim",  "https://media.hth4nh.eu.org/kkphim","", "KKPHIM.COM - Cung cấp dữ liệu phim trực tuyến Phụ Đề - Thuyết Minh - Lồng Tiếng cập nhật mới nhất MIỄN PHÍ và VĨNH VIỄN."),
    ("ophim",   "https://media.hth4nh.eu.org/ophim","", "Dữ liệu phim miễn phí vĩnh viễn. Cập nhật nhanh, chất lượng cao, ổn định và lâu dài."),
    ("nguonc",  "https://media.hth4nh.eu.org/nguonc","", "NGUỒN PHIM - Website cung cấp dữ liệu phim nhanh chất lượng cao. Phim online Vietsub, Thuyết minh, lồng tiếng chất lượng. Nguồn phim vietsub chất lượng cao cập nhật nhanh nhất."),
    ("phim4k",  "https://iptv.chjbi.net","", "Xem Phim Mới HD Online Vietsub, Thuyết Minh, Lồng Tiếng"),
    ("thvli",   "https://iptv.cameraddns.net","", "Phim Tổng Hợp - THVLi. Ứng dụng được LUKAHAI làm ra"),
    ("buncha",    "https://hxcv.site/buncha","", "Bún Chả TV - Trang web phát sóng bóng đá trực tuyến miễn phí hàng đầu tại Việt Nam, mang đến trải nghiệm chất lượng cao với bình luận tiếng Việt sống động."),
    ("fpt",     "https://iptv.nhadai.org/v1","", "FPT PLAY - Hệ thống kênh truyền hình trực tuyến đỉnh cao, tổng hợp các nội dung giải trí, thể thao, phim ảnh và chương trình đặc sắc nhất. Mang đến trải nghiệm mượt mà, chất lượng hình ảnh vượt trội qua kết nối Internet, FPT PLAY  là lựa chọn hàng đầu cho người dùng Việt Nam và quốc tế."),
    ("vtvgo",   "https://vtvgo.4share.me","", "VTVgo là sản phẩm của VTV, cung cấp nội dung trực tuyến đa dạng gồm kênh truyền hình, xem lại chương trình, Phim truyền hình, Video tin tức, Giải trí, Thể thao"),
    ("custom",  None,"", "URL JSON tùy chỉnh của bạn. Hãy nhập url tại Configure Addon"),
]

# Hình ảnh mặc định khi kênh không có logo
fallback_img = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path') + '/resources/media/fallback.jpg')
fallback_fanart = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path') + '/resources/media/fallback_fanart.jpg')

# ===== Hiển thị thông báo =====
def thong_bao(tieu_de, noi_dung, level=xbmcgui.NOTIFICATION_INFO, time=3000):
    """Hiển thị thông báo nhanh trên màn hình Kodi."""
    xbmcgui.Dialog().notification(tieu_de, noi_dung, level, time)

def show_donate_qr():
    """
    Hiển thị cửa sổ pop-up chứa hình ảnh QR Code.
    (Phiên bản đơn giản, dùng Dialog.imageviewer)
    """
    xbmc.log("[Film Free JSON] show_donate_qr (dùng imageviewer)", xbmc.LOGINFO)
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path')
        qr_image_path = os.path.join(addon_path, 'resources', 'media', 'QR_Donate.jpg')

        if not xbmcvfs.exists(qr_image_path):
            xbmc.log("[Film Free JSON] Không tìm thấy file donate_qr.png", xbmc.LOGERROR)
            thong_bao("Lỗi", "Không tìm thấy file ảnh QR Code.", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Tiêu đề hiển thị (Kodi sẽ tự hiển thị nút "Back")
        # heading = "Quét mã để ủng hộ tác giả (Nhấn 'Back' để thoát)"
        
        # ===== THAY ĐỔI QUAN TRỌNG: Dùng hàm imageviewer =====
        # Dòng này sẽ mở một cửa sổ pop-up/toàn màn hình chỉ để hiển thị ảnh
        # xbmcgui.Dialog().imageviewer(heading, qr_image_path)
        xbmc.executebuiltin(f"ShowPicture({qr_image_path})")
        # ===== KẾT THÚC THAY ĐỔI =====
        
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi hiển thị QR: {e}", xbmc.LOGERROR)
    finally:
        # Quan trọng: Báo cho Kodi biết plugin đã chạy xong
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True)

def tai_danh_sach_nguon(url_remote, ds_nguon_mac_dinh):
    """
    Tải danh sách nguồn từ một URL JSON remote.
    Nếu thất bại, sẽ sử dụng danh sách ds_nguon_mac_dinh.
    """
    xbmc.log(f"[Film Free JSON] Đang tải danh sách nguồn từ: {url_remote}", xbmc.LOGINFO)
    ds_nguon_moi = []
    
    try:
        # 1. Tải dữ liệu JSON từ URL
        data = tai_du_lieu_json(url_remote)
        
        # 2. Kiểm tra xem có phải là một danh sách không
        if not isinstance(data, list):
            xbmc.log(f"[Film Free JSON] Lỗi: JSON nguồn không phải là một danh sách.", xbmc.LOGERROR)
            raise Exception("JSON nguồn không phải là danh sách")

        # 3. Phân tích (parse) danh sách
        for item in data:
            if not isinstance(item, dict):
                continue
                
            # Lấy các trường. Dùng .get() để tránh lỗi nếu thiếu
            # (Bạn có thể sửa 'ma', 'url', 'mota' nếu JSON của bạn dùng tên khác)
            ma = item.get('ma') or item.get('key') # Thử lấy 'ma' hoặc 'key'
            url = item.get('url')
            img = item.get('image')
            mota = item.get('mota') or item.get('description') or "" # Thử lấy 'mota' hoặc 'description'
            
            # Nếu có đủ thông tin cơ bản (ma và url) thì thêm vào
            if ma and url:
                ds_nguon_moi.append((ma, url, img, mota))
            else:
                xbmc.log(f"[Film Free JSON] Bỏ qua nguồn: {item} (thiếu 'ma' hoặc 'url')", xbmc.LOGINFO)

        # 4. Nếu danh sách mới rỗng sau khi parse, coi như lỗi
        if not ds_nguon_moi:
            xbmc.log(f"[Film Free JSON] Lỗi: JSON nguồn không có mục nào hợp lệ.", xbmc.LOGERROR)
            raise Exception("Không phân tích được nguồn nào")

    except Exception as e:
        # 5. Nếu có bất kỳ lỗi nào (mạng, parse, ...), thông báo và dùng list mặc định
        xbmc.log(f"[Film Free JSON] Lỗi tải DS NGUON: {e}. Sử dụng danh sách mặc định.", xbmc.LOGERROR)
        thong_bao("Film Free JSON", "Lỗi tải danh sách nguồn, dùng mặc định.", xbmcgui.NOTIFICATION_WARNING)
        # TRẢ VỀ DANH SÁCH MẶC ĐỊNH
        return ds_nguon_mac_dinh

    # 6. Nếu thành công, thêm mục "custom" vào cuối danh sách đã tải
    # Tìm mục "custom" từ danh sách mặc định để thêm vào
    custom_entry = None
    for entry in ds_nguon_mac_dinh:
        if entry[0] == "custom":
            custom_entry = entry
            break
    
    if custom_entry:
        ds_nguon_moi.append(custom_entry)
        
    xbmc.log(f"[Film Free JSON] Đã tải thành công {len(ds_nguon_moi)} nguồn từ remote.", xbmc.LOGINFO)
    # xbmc.log(f"{ds_nguon_moi[0]}", xbmc.LOGINFO)
    return ds_nguon_moi

def duong_dan_profile():
    """Trả về đường dẫn thư mục dữ liệu người dùng của addon."""
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    except Exception:
        # Tương thích Kodi cũ
        return xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

def duong_dan_lich_su():
    """Trả về đường dẫn file lưu lịch sử xem phim."""
    path = duong_dan_profile()
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return os.path.join(path, "history.json")

def doc_lich_su():
    """Đọc danh sách lịch sử xem từ file."""
    xbmc.log(f"[Film Free JSON] doc_lich_su", xbmc.LOGINFO)
    file_path = duong_dan_lich_su()
    try:
        if not xbmcvfs.exists(file_path):
            return []
        f = xbmcvfs.File(file_path, 'r')
        data = f.read(); f.close()
        ds = json.loads(data or "[]")
        return ds if isinstance(ds, list) else []
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi đọc lịch sử: {e}", xbmc.LOGINFO)
        return []

def ghi_lich_su(ds):
    """Ghi danh sách lịch sử xem ra file."""
    xbmc.log(f"[Film Free JSON] ghi_lich_su", xbmc.LOGINFO)
    file_path = duong_dan_lich_su()
    try:
        f = xbmcvfs.File(file_path, 'w')
        f.write(json.dumps(ds, ensure_ascii=False))
        f.close()
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi ghi lịch sử: {e}", xbmc.LOGINFO)

def luu_lich_su(muc_ls):
    """Thêm hoặc cập nhật một mục trong lịch sử xem (tối đa 10 mục mỗi nguồn)."""
    xbmc.log(f"[Film Free JSON] luu_lich_su", xbmc.LOGINFO)
    ds = doc_lich_su()
    
    # Xác định khóa cho mục mới
    remote_url = muc_ls.get('remote_data', {}).get('url')
    source_key = muc_ls.get('source_key')
    
    if remote_url:
        # Ưu tiên dùng remote_url làm định danh
        khoa_moi = (source_key, remote_url)
    else:
        # Dùng tên làm định danh
        khoa_moi = (source_key, muc_ls.get('name'))

    # Lọc danh sách cũ, loại bỏ bất kỳ mục nào trùng khóa
    ds_tam = []
    for it in ds:
        it_remote_url = it.get('remote_data', {}).get('url')
        it_source_key = it.get('source_key')
        
        if it_remote_url:
            khoa_cu = (it_source_key, it_remote_url)
        else:
            khoa_cu = (it_source_key, it.get('name'))
            
        if khoa_cu != khoa_moi:
            ds_tam.append(it)
    
    # Chèn mục mới lên đầu
    ds_tam.insert(0, muc_ls)
    
    # (Phần còn lại giữ nguyên: Giới hạn 10 mục / Sắp xếp)
    ds_moi = []
    dem = {}
    for it in ds_tam:
        key = it.get('source_key') or 'unknown'
        dem[key] = dem.get(key, 0) + 1
        if dem[key] <= 10:
            ds_moi.append(it)
            
    # Sắp xếp theo thời gian mới nhất
    ds_moi.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
    ghi_lich_su(ds_moi)

def xoa_muc_lich_su(index):
    """Xóa một mục lịch sử xem theo chỉ số."""
    xbmc.log(f"[Film Free JSON] xoa_muc_lich_su: {index}", xbmc.LOGINFO)
    ds = doc_lich_su()
    if index < 0 or index >= len(ds):
        thong_bao("Film Free JSON", "Mục lịch sử không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
        return
    del ds[index]
    ghi_lich_su(ds)
    thong_bao("Film Free JSON", "Đã xóa khỏi lịch sử")
    hien_thi_lich_su()

def tai_du_lieu_json(url, headers=None):
    """Tải dữ liệu JSON từ URL với timeout 5s, thử tối đa 3 lần."""
    # Tạo các header mặc định
    final_headers = {
        'user-agent': UA,
        'referer': url  # Dùng chính URL làm Referer
    }
     # Cập nhật (hoặc ghi đè) bằng các header tùy chỉnh nếu có
    if isinstance(headers, dict):
        final_headers.update(headers)
    
    for thu in range(3):  # thử tối đa 3 lần (1 lần đầu + 2 lần retry)
        try:
            req = request.Request(url)
            if final_headers:
                # Gắn header nếu có
                for k, v in final_headers.items():
                    try:
                        req.add_header(k, v)
                    except Exception:
                        pass
            # Mở URL với timeout 5s
            with request.urlopen(req, timeout=10) as resp:
                data = resp.read()
            # Giải mã JSON
            return json.loads(data)
        except Exception as e:
            xbmc.log(f"[Film Free JSON] Lỗi tải JSON (thử {thu+1}): {e}", xbmc.LOGINFO)
            if thu == 2:
                # Nếu thử lần cuối vẫn lỗi, ném ngoại lệ
                raise
            # Nếu chưa quá số lần retry, thử lại
            continue

def them_header_vao_url(url_goc, headers):
    """Kết hợp URL với header thành định dạng mà Kodi hiểu: url|Header1=V1&Header2=V2"""
    if not headers:
        return url_goc
    header_parts = [f"{k}={v}" for k, v in headers.items() if v]
    return f"{url_goc}|{'&'.join(header_parts)}" if header_parts else url_goc

def chuyen_headers_sang_dict(ds_headers):
    """Chuyển đổi danh sách header dạng [{key,value}] thành dict {key: value}."""
    result = {}
    if isinstance(ds_headers, list):
        for it in ds_headers:
            if isinstance(it, dict):
                k = it.get('key'); v = it.get('value')
                if k and v:
                    result[str(k)] = str(v)
    return result

def lay_url_playlist():
    """
    Trả về URL playlist JSON dựa trên lựa chọn đã lưu trong settings.
    Ưu tiên: Custom -> Active -> Fallback.
    """
    addon = xbmcaddon.Addon()
    
    # Ưu tiên 1: Nguồn tùy chỉnh (Custom) do người dùng tự nhập
    custom_url = addon.getSetting("custom_source") or ""
    if custom_url.strip():
        xbmc.log(f"[Film Free JSON] Dùng URL tùy chỉnh: {custom_url}", xbmc.LOGINFO)
        return custom_url.strip()

    # Ưu tiên 2: Nguồn đang hoạt động (Active) được lưu từ menu [Đổi Nguồn]
    active_url = addon.getSetting("active_source_url") or ""
    if active_url.strip():
        xbmc.log(f"[Film Free JSON] Dùng URL đang hoạt động: {active_url}", xbmc.LOGINFO)
        return active_url.strip()
        
    # Ưu tiên 3: Nguồn Legacy (cho tương thích cũ)
    url_legacy = addon.getSetting("playlist_url") or ""
    if url_legacy.strip():
        xbmc.log(f"[Film Free JSON] Dùng URL legacy: {url_legacy}", xbmc.LOGINFO)
        return url_legacy.strip()

    # Ưu tiên 4: Fallback (Nếu chưa chọn gì)
    # Lấy nguồn đầu tiên từ danh sách MẶC ĐỊNH (phòng trường hợp remote JSON lỗi)
    try:
        # (ma, url, img, desc)
        fallback_url = DANH_SACH_NGUON_MACDINH[0][1]
        xbmc.log(f"[Film Free JSON] Dùng URL mặc định (fallback): {fallback_url}", xbmc.LOGINFO)
        # Tự động lưu URL này làm URL "đang hoạt động" cho lần sau
        addon.setSetting("active_source_url", fallback_url)
        return fallback_url
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi nghiêm trọng, không có nguồn mặc định: {e}", xbmc.LOGERROR)
        thong_bao("Film Free JSON", "Lỗi nghiêm trọng, không có nguồn mặc định", xbmcgui.NOTIFICATION_ERROR)
        return ""

# ===== Tạo playlist Kodi cho nhiều tập phim =====
def tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=None):
    """
    (PHIÊN BẢN ĐA NĂNG)
    Tạo playlist Kodi, tự động xử lý Phim Lẻ (movie) và Phim Bộ (episode).
    """
    xbmc.log(f"[Film Free JSON] Tạo playlist phim: {film_name} - {len(ds_tap)} tập", xbmc.LOGINFO)
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    thong_bao("Film Free JSON", "Đang tạo playlist phim", xbmcgui.NOTIFICATION_INFO)

    # 1. Tìm số Mùa (Giữ nguyên logic của bạn, rất tốt)
    season_num = tim_so_mua(film_name)
    
    # Biến đếm số tập hợp lệ
    added_count = 0 

    for idx, stream in enumerate(ds_tap):
        
        # Chỉ bắt đầu thêm từ tập 'start_index' mà người dùng chọn
        # if idx < start_index:
            # continue

        # 2. Xác định loại (Logic của bạn, rất tốt)
        media_type = 'episode' # Mặc định là phim bộ
        if len(ds_tap) == 1:
            media_type = 'movie'

        # 3. Lấy link (dùng hàm trợ giúp)
        ds_link = lay_ds_link_tu_tap(stream)
        if not ds_link:
            xbmc.log(f"[Film Free JSON] Bỏ qua tập {idx+1} (không có link)", xbmc.LOGINFO)
            continue
            
        # 4. CHỌN LINK (Sử dụng hàm trợ giúp - Cải tiến 1)
        link_chon = chon_link_tot_nhat(ds_link)
        
        if not link_chon or not link_chon.get('url'):
            xbmc.log(f"[Film Free JSON] Bỏ qua tập {idx+1} (không chọn được link tốt)", xbmc.LOGINFO)
            continue
            
        url_phat = link_chon.get('url')
        headers = link_chon.get('headers') or chuyen_headers_sang_dict(link_chon.get('request_headers'))
        url_kodi = them_header_vao_url(url_phat, headers)
        
        # 5. TẠO LISTITEM & METADATA (Sửa 2 lỗi nghiêm trọng)
        
        # Lấy tên tập
        ep_name = stream.get('name') or f"Tập {idx+1}"
        
        list_item = xbmcgui.ListItem(label=ep_name) # Label của tập
        list_item.setProperty("IsPlayable", "true")
        
        list_item.setContentLookup(False)
        
        list_item_info = list_item.getVideoInfoTag()
        list_item_info.setPlot(desc)

        # ===== SỬA LỖI 2: Tách metadata cho movie/episode =====
        if media_type == 'movie':
            # --- A. Đây là PHIM LẺ ---
            list_item_info.setMediaType('movie')
            list_item_info.setTitle(film_name) 
            
        else:
            # --- B. Đây là TẬP PHIM ---
            list_item_info.setMediaType('episode')
            list_item_info.setTitle(ep_name)
            list_item_info.setEpisode(idx + 1)
            list_item_info.setTvShowTitle(film_name)
            
            # Gán season
            if season_num:
                list_item_info.setSeason(season_num)
            else:
                list_item_info.setSeason(1) # Mặc định mùa 1
        
        # 6. MimeType và Subtitles (Giữ nguyên)
        try:
            if (link_chon.get('type') or '').lower() == 'hls':
                list_item.setMimeType('application/x-mpegURL')
        except Exception:
            pass
        
        ds_sub_urls = []
        subs = link_chon.get('subtitles') if link_chon else None
        if isinstance(subs, list):
            for sub in subs:
                su = sub.get('url')
                if not su:
                    continue
                sh = sub.get('headers') or chuyen_headers_sang_dict(sub.get('request_headers'))
                ds_sub_urls.append(them_header_vao_url(su, sh) if sh else su)
        if ds_sub_urls:
            try:
                list_item.setSubtitles(ds_sub_urls)
            except Exception as e:
                xbmc.log(f"[Film Free JSON] setSubtitles lỗi: {e}", xbmc.LOGINFO)
                
        # Thêm vào playlist
        playlist.add(url_kodi, list_item)
        added_count += 1
        
    
    if added_count == 0:
        thong_bao("Film Free JSON", "Không có nội dung để phát", xbmcgui.NOTIFICATION_ERROR)
        return False
        
    # Phát từ item đầu của playlist (tức chính là tập start_index)
    try:
        # xbmc.Player().play(playlist)
        xbmc.Player().play(playlist, startpos=start_index)
    except TypeError:
        xbmc.Player().play(playlist)
        
    return True

# ===== Phát nội dung trực tiếp (phim lẻ hoặc kênh stream đơn) =====
def phat_truc_tiep(chiso_kenh, chiso_nhom=None):
    """
    (ĐÃ NÂNG CẤP)
    Phát kênh hoặc phim có luồng trực tiếp (phim lẻ).
    Sử dụng logic chon_link_tot_nhat và hỗ trợ phụ đề.
    """
    xbmc.log(f"[Film Free JSON] phat_truc_tiep (NÂNG CẤP): {chiso_kenh}, {chiso_nhom}", xbmc.LOGINFO)
    try:
        # 1. Tải playlist JSON và xác định kênh
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_nhom = playlist.get('groups') or playlist.get('items') or []
        
        if chiso_nhom is not None and 0 <= chiso_nhom < len(ds_nhom):
            nhom = ds_nhom[chiso_nhom]
            ds_kenh = nhom.get('channels') or nhom.get('items') or []
        else:
            # Nếu không có nhóm (hoặc chiso_nhom=None), thử lấy 'channels' từ gốc
            ds_kenh = playlist.get('channels') or playlist.get('items') or []
            
        if not (0 <= chiso_kenh < len(ds_kenh)):
            thong_bao("Film Free JSON", "Kênh không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
            
        kenh = ds_kenh[chiso_kenh]
        ten_kenh = kenh.get('name') or kenh.get('title') or "Nội dung"
        
        # 2. Lấy danh sách link (dùng hàm trợ giúp)
        # Hàm 'lay_ds_link_tu_tap' hoạt động hoàn hảo ở đây
        # vì 'kenh' có cấu trúc giống 'episode' (có thể chứa 'remote_data' hoặc 'streams')
        ds_link = lay_ds_link_tu_tap(kenh)
        
        if not ds_link:
            thong_bao("Film Free JSON", "Không tìm thấy luồng phát", xbmcgui.NOTIFICATION_ERROR)
            return

        # 3. Chọn link tốt nhất (dùng hàm trợ giúp)
        link_chon = chon_link_tot_nhat(ds_link)
        
        if not link_chon or not link_chon.get('url'):
            thong_bao("Film Free JSON", "Không tìm thấy URL phát khả dụng", xbmcgui.NOTIFICATION_ERROR)
            return

        # 4. Lấy thông tin từ link đã chọn
        stream_url = link_chon.get('url')
        headers = link_chon.get('headers') or chuyen_headers_sang_dict(link_chon.get('request_headers'))
        url_kodi = them_header_vao_url(stream_url, headers)

        # 5. Lưu lịch sử xem (phim lẻ)
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        muc_ls = {
            "name": ten_kenh,
            "timestamp": int(time.time()),
            "type": "full",
            "episode_name": "Full",
            "url_kodi": url_kodi
        }
        if rd and rd.get('url'):
            muc_ls["remote_data"] = rd
        
        # Sửa lỗi logic lấy source_key: Phải đọc 'active_source_url' thay vì 'preset_source'
        try:
            addon = xbmcaddon.Addon()
            active_url = (addon.getSetting("active_source_url") or "").strip()
            custom_url = (addon.getSetting("custom_source") or "").strip()
            
            url_dang_chon = custom_url if custom_url else active_url
            
            # Tìm 'ma' (source_key) dựa trên URL đang chạy
            muc_ls["source_key"] = "custom" # Mặc định là custom
            if not custom_url:
                for (ma, url, img, desc) in lay_ds_nguon_da_tai():
                    if url == url_dang_chon:
                        muc_ls["source_key"] = ma
                        break
            # Nếu không tìm thấy (ví dụ: dùng fallback), gán tạm
            if not muc_ls.get("source_key") and lay_ds_nguon_da_tai():
                 muc_ls["source_key"] = lay_ds_nguon_da_tai()[0][0]
                 
        except Exception as e:
            xbmc.log(f"[Film Free JSON] Lỗi lấy source_key cho lịch sử: {e}", xbmc.LOGINFO)
            if lay_ds_nguon_da_tai():
                 muc_ls["source_key"] = lay_ds_nguon_da_tai()[0][0] # Fallback an toàn

        luu_lich_su(muc_ls)
        
        # 6. Chuẩn bị ListItem để phát
        item = xbmcgui.ListItem(path=url_kodi, label=ten_kenh)
        item.setProperty("IsPlayable", "true")
        
        # Lấy InfoTag từ 'kenh'
        info = item.getVideoInfoTag()
        info.setTitle(ten_kenh)
        info.setPlot(kenh.get('description') or "")
        info.setMediaType('movie') # Báo cho skin đây là phim lẻ

        # 7. Gắn phụ đề (Subtitles) nếu có
        ds_sub_urls = []
        subs = link_chon.get('subtitles')
        if isinstance(subs, list):
            for sub in subs:
                su = sub.get('url')
                if not su: continue
                sh = sub.get('headers') or chuyen_headers_sang_dict(sub.get('request_headers'))
                ds_sub_urls.append(them_header_vao_url(su, sh) if sh else su)
        if ds_sub_urls:
            try:
                item.setSubtitles(ds_sub_urls)
            except Exception as e:
                 xbmc.log(f"[Film Free JSON] setSubtitles lỗi: {e}", xbmc.LOGINFO)

        # 8. Gắn MimeType (nếu là HLS)
        if (link_chon.get('type') or '').lower() == 'hls':
            try:
                item.setMimeType('application/x-mpegURL')
            except Exception:
                pass
                
        # 9. Phát video
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=item)
        
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi phat_truc_tiep: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi phát: {e}", xbmcgui.NOTIFICATION_ERROR)

# ===== Hiển thị danh sách nhóm và kênh =====
def hien_thi_menu_du_phong(error_msg):
    """Hiển thị menu giới hạn khi không tải được nguồn chính."""
    xbmc.log(f"[Film Free JSON] Hiển thị menu dự phòng. Lỗi: {error_msg}", xbmc.LOGWARNING)
    xbmcplugin.setContent(addon_handle, 'files')
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    # Thông báo lỗi trên màn hình
    thong_bao("Film Free JSON", f"Lỗi tải nguồn: {error_msg}", xbmcgui.NOTIFICATION_ERROR)
    
    # === DONATE ====
    item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
    item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
    info_donate = item_donate.getVideoInfoTag()
    info_donate.setTitle("[Xin ủng hộ Tác giả]")
    info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
    
    # Đổi Nguồn
    item_source = xbmcgui.ListItem(label="[Đổi Nguồn Dữ Liệu]", label2="Chọn các nguồn dữ liệu khác")
    img_source = os.path.join(media_path, 'icon_swap.png')
    item_source.setArt({'thumb': img_source, 'icon': img_source, 'poster': img_source, 'fanart': fallback_fanart, 'banner': fallback_fanart}) 
    info_item_source = item_source.getVideoInfoTag()
    info_item_source.setTitle("[Đổi Nguồn Dữ Liệu]")
    info_item_source.setPlot("Chọn các nguồn dữ liệu khác")
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=doi_nguon", item_source, isFolder=True)
    
    # 1. Mục thông báo lỗi (Không có action)
    item_error = xbmcgui.ListItem(label="[LỖI] Nguồn đang lỗi, hãy đổi nguồn khác")
    item_error.setArt({'thumb': os.path.join(media_path, 'icon_error.png'), 'icon': os.path.join(media_path, 'icon_error.png')})
    info_item_error = item_error.getVideoInfoTag()
    info_item_error.setTitle("[LỖI] Nguồn đang lỗi, hãy đổi nguồn khác")
    info_item_error.setPlot(f"Nguồn bạn chọn hiện tại không thể truy cập, mã lỗi: {error_msg}")
    # Action Bấm vào cho đổi nguồn khác
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=doi_nguon", item_error, isFolder=True)
    
    # Kết thúc
    xbmcplugin.endOfDirectory(addon_handle)

def hien_thi_nhom():
    """Hiển thị danh sách nhóm nội dung (nếu có) hoặc danh sách kênh nếu không có nhóm."""
    xbmc.log(f"[Film Free JSON] hien_thi_nhom", xbmc.LOGINFO)
    url_playlist = lay_url_playlist()
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    xbmcplugin.setContent(addon_handle, 'movies')
    try:
        # Cố gắng tải playlist
        playlist = tai_du_lieu_json(url_playlist)
        
        # Kiểm tra dữ liệu rỗng hoặc sai định dạng
        if not playlist or not isinstance(playlist, dict):
             raise Exception("Dữ liệu JSON trống hoặc không hợp lệ")
             
    except Exception as e:
        hien_thi_menu_du_phong(str(e))
        return
        
    ds_nhom = playlist.get('groups') or playlist.get('items') or []
    ds_channels_moi = playlist.get('channels') or []
    load_more = playlist.get('load_more') or []
    if ds_nhom:
        # === DONATE ====
        item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
        item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
        info_donate = item_donate.getVideoInfoTag()
        info_donate.setTitle("[Xin ủng hộ Tác giả]")
        info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
        
        # Đổi Nguồn
        item_source = xbmcgui.ListItem(label="[Đổi Nguồn Dữ Liệu]", label2="Chọn các nguồn dữ liệu khác")
        img_source = os.path.join(media_path, 'icon_swap.png')
        item_source.setArt({'thumb': img_source, 'icon': img_source, 'poster': img_source, 'fanart': fallback_fanart, 'banner': fallback_fanart}) 
        info_item_source = item_source.getVideoInfoTag()
        info_item_source.setTitle("[Đổi Nguồn Dữ Liệu]")
        info_item_source.setPlot("Chọn các nguồn dữ liệu khác")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=doi_nguon", item_source, isFolder=True)
        
        # Thêm mục Tìm kiếm và Lịch sử xem ở đầu danh sách
        item_search = xbmcgui.ListItem(label="[Tìm kiếm]", label2="Tìm nội dung trong nguồn này")
        img_search = os.path.join(media_path, 'icon_search.png')
        item_search.setArt({'thumb': img_search, 'icon': img_search, 'poster': img_search, 'fanart': fallback_fanart, 'banner': fallback_fanart})
        info_item_search = item_search.getVideoInfoTag()
        info_item_search.setTitle("[Tìm kiếm]")
        info_item_search.setPlot("Tìm nội dung trong nguồn này")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=search_input", item_search, isFolder=True)
        
        # Lịch sử
        item_hist = xbmcgui.ListItem(label="[Lịch sử xem]", label2="Xem lịch sử các nội dung đã xem")
        img_hist = os.path.join(media_path, 'icon_history.png')
        item_hist.setArt({'thumb': img_hist, 'poster': img_hist, 'icon': img_hist, 'fanart': fallback_fanart, 'banner': fallback_fanart})
        info_item_hist = item_hist.getVideoInfoTag()
        info_item_hist.setTitle("[Lịch sử xem]")
        info_item_hist.setPlot("Xem lịch sử các nội dung đã xem")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=lich_su_xem", item_hist, isFolder=True)
        
        # ===== BẮT ĐẦU MỤC "XEM THÊM" MỚI =====
        item_xem_them = xbmcgui.ListItem(label=">>> Xem thêm Bộ lọc <<<", label2="Duyệt phim theo thể loại, quốc gia...")
        img_filter = tao_hinh_placeholder("Xem thêm Bộ lọc")
        item_xem_them.setArt({'thumb': img_filter, 'icon': img_filter, 'poster': img_filter, 'fanart': fallback_fanart, 'banner': fallback_fanart})
        info_xem_them = item_xem_them.getVideoInfoTag()
        info_xem_them.setTitle(">>> Xem thêm-Bộ lọc <<<")
        info_xem_them.setPlot("Duyệt phim theo thể loại, quốc gia và các bộ lọc khác do nguồn cung cấp.")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=mo_xem_them", item_xem_them, isFolder=True)
        
        # Liệt kê các nhóm
        for idx, nhom in enumerate(ds_nhom):
            ds_channels = nhom.get('channels')
            ten_nhom = nhom.get('name') or nhom.get('title') or f"Group {idx+1}"
            if not ds_channels:
                xbmc.log(f"[Film Free JSON] hien_thi_nhom Bỏ qua nhóm: {ten_nhom}", xbmc.LOGINFO)
                continue
            item = xbmcgui.ListItem(label=ten_nhom)
            img_channel = tao_hinh_placeholder(ten_nhom)
            item.setArt({'thumb': img_channel, 'icon': img_channel, 'poster': img_channel, 'fanart': fallback_fanart, 'banner': fallback_fanart})
            xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=open_group&g={idx}", item, isFolder=True)
        # Nếu nguồn có channels trực tiếp thì load ra Home menu bằng tai_noi_dung_moi
        if ds_channels_moi and load_more:
            tai_noi_dung_moi(ds_channels_moi, load_more)
        ep_view_toan_cuc()
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        # Nếu không có nhóm, hiển thị trực tiếp danh sách kênh
        ds_kenh = playlist.get('channels') or playlist.get('items') or []
        if not ds_kenh:
            thong_bao("Film Free JSON", "Danh sách trống", xbmcgui.NOTIFICATION_ERROR)
            return
        hien_thi_kenh_theo_danh_sach(ds_kenh, chiso_nhom=None)

def hien_thi_kenh_trong_nhom(chiso_nhom):
    """Hiển thị danh sách kênh trong một nhóm nội dung."""
    xbmc.log(f"[Film Free JSON] hien_thi_kenh_trong_nhom: {chiso_nhom}", xbmc.LOGINFO)
    try:
        playlist = tai_du_lieu_json(lay_url_playlist())
    except Exception as e:
        thong_bao("Film Free JSON", f"Lỗi tải danh sách: {e}", xbmcgui.NOTIFICATION_ERROR)
        return
    ds_nhom = playlist.get('groups') or playlist.get('items') or []
    if chiso_nhom < 0 or chiso_nhom >= len(ds_nhom):
        thong_bao("Film Free JSON", "Nhóm không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
        return
    nhom = ds_nhom[chiso_nhom]
    ds_kenh = nhom.get('channels') or nhom.get('items') or []
    if not ds_kenh:
        thong_bao("Film Free JSON", "Nhóm không có nội dung", xbmcgui.NOTIFICATION_ERROR)
        return
    hien_thi_kenh_theo_danh_sach(ds_kenh, chiso_nhom=chiso_nhom)

def hien_thi_kenh_theo_danh_sach(ds_kenh, chiso_nhom):
    """Hiển thị danh sách kênh (phim) từ một danh sách cho trước."""
    xbmc.log(f"[Film Free JSON] hien_thi_kenh_theo_danh_sach: {len(ds_kenh)} phim, nhóm {chiso_nhom}", xbmc.LOGINFO)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    # === DONATE ====
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
    item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
    info_donate = item_donate.getVideoInfoTag()
    info_donate.setTitle("[Xin ủng hộ Tác giả]")
    info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
    # === END DONATE ====
    for idx, kenh in enumerate(ds_kenh):
        loai = (kenh.get('type') or '').lower()
        ten_kenh = kenh.get('name') or kenh.get('title') or f"Channel {idx+1}"
        logo = None
        # Bỏ qua các mục quảng cáo nếu có
        if loai in ('ad', 'banner'):
            continue
        # Lấy ảnh logo nếu có
        if isinstance(kenh.get('image'), str):
            logo = kenh['image']
        elif isinstance(kenh.get('image'), dict):
            logo = kenh['image'].get('url')
        if not logo:
            logo = kenh.get('logo')
            
        desc = kenh.get('description') or ""
        
        item = xbmcgui.ListItem(label=ten_kenh, label2=desc)
        info = item.getVideoInfoTag()
        info.setTitle(ten_kenh)
        
        # setMediaType
        loai_phim = tim_loai_phim(loai)
        info.setMediaType(loai_phim)
        
        # setArt
        if logo:
            item.setArt({'thumb': logo, 'icon': logo})
        else:
            item.setArt({'thumb': fallback_img, 'icon': fallback_img})
            
        # setPlot
        if desc:
            info.setPlot(desc)
            
        # Xác định loại: có stream trực tiếp hay cần mở kênh (nhiều tập/nhiều nguồn)
        co_stream_truc_tiep = bool(kenh.get('stream') or kenh.get('streams'))
        co_remote = bool(kenh.get('remote_data') or kenh.get('remoteData'))
        co_sources = bool(kenh.get('sources'))
        if co_stream_truc_tiep and not co_remote and not co_sources:
            # Kênh/phim có link trực tiếp (phim lẻ)
            item.setProperty('IsPlayable', 'true')
            url_play = f"{base_url}?action=play_direct&i={idx}"
            if chiso_nhom is not None:
                url_play += f"&g={chiso_nhom}"
            xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=False)
        elif co_remote or co_sources:
            # Phim bộ hoặc có nhiều nguồn
            url_open = f"{base_url}?action=open_channel&i={idx}"
            if chiso_nhom is not None:
                url_open += f"&g={chiso_nhom}"
            xbmcplugin.addDirectoryItem(addon_handle, url_open, item, isFolder=True)
        else:
            # Kênh không có dữ liệu phát
            xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)
            
    ep_view_toan_cuc()
    xbmcplugin.endOfDirectory(addon_handle)

# ===== Mở kênh channels(phim) =====
def mo_kenh(chiso_nhom, chiso_kenh):
    """Mở kênh (phim) để chọn nguồn hoặc phát tập."""
    xbmc.log(f"[Film Free JSON] mo_kenh: {chiso_nhom}, {chiso_kenh}", xbmc.LOGINFO)
    
    try:
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_nhom = playlist.get('groups') or playlist.get('items') or []
        if chiso_nhom is not None and 0 <= chiso_nhom < len(ds_nhom):
            nhom = ds_nhom[chiso_nhom]
            ds_kenh = nhom.get('channels') or nhom.get('items') or []
        else:
            ds_kenh = playlist.get('channels') or playlist.get('items') or []
        if chiso_kenh < 0 or chiso_kenh >= len(ds_kenh):
            thong_bao("Film Free JSON", "Kênh không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        kenh = ds_kenh[chiso_kenh]
        loai = (kenh.get('type') or '').lower()
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        # Lấy danh sách nguồn phát
        if rd and rd.get('url'):
            # Nếu có remote_data, tải JSON chi tiết kênh
            headers_call = None
            if isinstance(rd.get('headers'), dict):
                headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list):
                headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
            data = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data.get('sources') or []
        else:
            ds_nguon = kenh.get('sources') or []
        if not ds_nguon:
            thong_bao("Film Free JSON", "Không tìm thấy nguồn phát", xbmcgui.NOTIFICATION_ERROR)
            return
        if len(ds_nguon) == 1:
            # Chỉ có 1 nguồn, xử lý trực tiếp nội dung
            nguon = ds_nguon[0]
            nguon_name = nguon.get('name') or ""
            # Lấy danh sách tập
            ds_tap = lay_ds_tap_tu_nguon(nguon)
            if not ds_tap:
                thong_bao("Film Free JSON", "Nguồn không có tập nào", xbmcgui.NOTIFICATION_ERROR)
                return
            film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
            thumb_url = kenh.get('image').get('url') or ""
            desc = kenh.get('description') or ""
            if len(ds_tap) == 1:
                # Xử lý phim 1 tập
                muc_ls = {
                    "name": film_name,
                    "thumb_url":thumb_url,
                    "description":desc,
                    "timestamp": int(time.time()),
                    "type": loai,
                    "source_index": 0,
                    "source_name": nguon_name,
                    "episode_index": 0,
                    "episode_total": len(ds_tap),
                    "episode_name": ds_tap[0].get('name') or "Tập 1"
                }
                if rd and rd.get('url'):
                    muc_ls["remote_data"] = rd
                try:
                    preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
                except:
                    preset_idx = 0
                preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
                muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
                luu_lich_su(muc_ls)
                # tạo playlist với 1 tập luôn
                tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
            else:
                # Nếu nhiều tập -> phát toàn bộ dưới dạng playlist Kodi
                # Lưu lịch sử xem với tập bắt đầu là 0 (Tiếp tục từ đầu)
                muc_ls = {
                    "name": film_name,
                    "thumb_url":thumb_url,
                    "description":desc,
                    "timestamp": int(time.time()),
                    "type": loai,
                    "source_index": 0,
                    "source_name": nguon_name,
                    "episode_index": 0,
                    "episode_total": len(ds_tap),
                    "episode_name": ds_tap[0].get('name') or "Tập 1"
                }
                if rd and rd.get('url'):
                    muc_ls["remote_data"] = rd
                try:
                    preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
                except:
                    preset_idx = 0
                preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
                muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
                luu_lich_su(muc_ls)
                # Tạo và phát playlist các tập
                tao_playlist_kodi(ds_tap, film_name, start_index=0,desc=desc)
            # Kết thúc, không cần hiển thị danh sách
            return
        else:
            # Nhiều nguồn, hiển thị danh sách nguồn để chọn
            for i, nguon in enumerate(ds_nguon):
                xbmcplugin.setContent(addon_handle, 'files')
                xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
                film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
                thumb_url = kenh.get('image').get('url') or ""
                desc = kenh.get('description') or ""
                ten = nguon.get('name') or nguon.get('id') or f"Source {i+1}"
                item = xbmcgui.ListItem(label=f"{film_name} - {ten}", label2=desc)
                info = item.getVideoInfoTag()
                info.setTitle(f"{film_name} - {ten}")
                info.setPlot(desc)
                # setMediaType
                loai_phim = tim_loai_phim(loai)
                info.setMediaType(loai_phim)
                
                # setArt
                if thumb_url:
                    item.setArt({'thumb': thumb_url, 'icon': thumb_url, 'poster': thumb_url, 'fanart': thumb_url, 'banner': thumb_url})
                else:
                    item.setArt({'thumb': fallback_img, 'icon': fallback_img, 'fanart': fallback_fanart, 'banner': fallback_fanart})
                url_mo = f"{base_url}?action=open_source&g={chiso_nhom if chiso_nhom is not None else -1}&i={chiso_kenh}&s={i}"
                xbmcplugin.addDirectoryItem(addon_handle, url_mo, item, isFolder=True)
                
            xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mo_kenh: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi mở kênh: {e}", xbmcgui.NOTIFICATION_ERROR)

# ===== Mở một nguồn cụ thể của kênh (sources) =====
def mo_nguon(chiso_nhom, chiso_kenh, chiso_nguon):
    """Mở một nguồn phát cụ thể và hiển thị/phát nội dung các tập."""
    xbmc.log(f"[Film Free JSON] mo_nguon: {chiso_nhom}, {chiso_kenh}, {chiso_nguon}", xbmc.LOGINFO)
    try:
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_nhom = playlist.get('groups') or playlist.get('items') or []
        if chiso_nhom is not None and 0 <= chiso_nhom < len(ds_nhom):
            nhom = ds_nhom[chiso_nhom]
            ds_kenh = nhom.get('channels') or nhom.get('items') or []
        else:
            ds_kenh = playlist.get('channels') or playlist.get('items') or []
        if chiso_kenh < 0 or chiso_kenh >= len(ds_kenh):
            thong_bao("Film Free JSON", "Kênh không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        kenh = ds_kenh[chiso_kenh]
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        loai = (kenh.get('type') or '').lower()
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            headers_call = None
            if isinstance(rd.get('headers'), dict):
                headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list):
                headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
            data = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data.get('sources') or []
        else:
            ds_nguon = kenh.get('sources') or []
        if chiso_nguon < 0 or chiso_nguon >= len(ds_nguon):
            thong_bao("Film Free JSON", "Nguồn không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        nguon = ds_nguon[chiso_nguon]
        nguon_name = nguon.get('name') or ""
        # Lấy danh sách tập từ nguồn
        ds_tap = lay_ds_tap_tu_nguon(nguon)
        if not ds_tap:
            thong_bao("Film Free JSON", "Nguồn không có tập nào", xbmcgui.NOTIFICATION_ERROR)
            return
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        if len(ds_tap) == 1:
            # Nếu chỉ có 1 tập
            muc_ls = {
                "name": film_name,
                "thumb_url":thumb_url,
                "description":desc,
                "timestamp": int(time.time()),
                "type": loai,
                "source_index": chiso_nguon,
                "source_name":nguon_name,
                "episode_index": 0,
                "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
            }
            if rd and rd.get('url'):
                muc_ls["remote_data"] = rd
            try:
                preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
            except:
                preset_idx = 0
            preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
            muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
            luu_lich_su(muc_ls)
            # phát bằng playlist luôn
            tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
        else:
            # Nếu nhiều tập -> phát tất cả dưới dạng playlist
            muc_ls = {
                "name": film_name,
                "thumb_url":thumb_url,
                "description":desc,
                "timestamp": int(time.time()),
                "type": loai,
                "source_index": chiso_nguon,
                "source_name":nguon_name,
                "episode_index": 0,
                "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
            }
            if rd and rd.get('url'):
                muc_ls["remote_data"] = rd
            try:
                preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
            except:
                preset_idx = 0
            preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
            muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
            luu_lich_su(muc_ls)
            tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mo_nguon: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi liệt kê tập: {e}", xbmcgui.NOTIFICATION_ERROR)

# ===== Hiển thị lịch sử xem =====
def hien_thi_lich_su():
    """Hiển thị danh sách các phim đã xem trong lịch sử."""
    xbmc.log(f"[Film Free JSON] hien_thi_lich_su", xbmc.LOGINFO)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    
    ds = doc_lich_su()
    # === DONATE ====
    media_path = os.path.join(addon_path, 'resources', 'media')
    item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
    item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
    info_donate = item_donate.getVideoInfoTag()
    info_donate.setTitle("[Xin ủng hộ Tác giả]")
    info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
    
    # Xóa lịch sử - đưa chức năng này vào đây thay vì homepage
    item_clear = xbmcgui.ListItem(label="[Xóa lịch sử xem]", label2="Xóa các nội dung đã xem")
    img_clear = os.path.join(media_path, 'icon_clear.png')
    item_clear.setArt({'thumb': img_clear, 'icon': img_clear, 'poster': img_clear, 'fanart': fallback_fanart, 'banner': fallback_fanart})
    info_item_clear = item_clear.getVideoInfoTag()
    info_item_clear.setTitle("[Xóa lịch sử xem]")
    info_item_clear.setPlot("Xóa các nội dung đã xem")
    xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=xoa_lich_su", item_clear, isFolder=False)
    
    if not ds:
        thong_bao("Film Free JSON", "Chưa có lịch sử xem.")
        xbmcplugin.endOfDirectory(addon_handle)
        return
    for i, it in enumerate(ds):
        t = it.get('name') or f"Mục {i+1}"
        phu = it.get('description') or ""
        logo = it.get('thumb_url') or ""
        nguon_name = it.get('source_name') or ""
        loai = it.get('type') or ""
        ten = f"{t} - {nguon_name}"
        
        item = xbmcgui.ListItem(label=t, label2=phu)
        item.setArt({'thumb': logo, 'icon': logo})
        info = item.getVideoInfoTag()
        info.setTitle(t)
        info.setPlot(phu)
        info.setGenres([nguon_name])
        
        # setMediaType
        loai_phim = tim_loai_phim(loai)
        info.setMediaType(loai_phim)
        
        # Menu ngữ cảnh cho từng mục lịch sử - chỉ áp dụng cho xóa 1 mục lịch sử
        menu_items = []
        menu_items.append(("Xóa khỏi lịch sử", f"RunPlugin({base_url}?action=remove_history_item&i={i})"))
        item.addContextMenuItems(menu_items)
        item.setProperty('IsPlayable', 'true')
        # url = f"{base_url}?action=play_from_history&i={i}"
        url = f"{base_url}?action=open_history_item&i={i}"
        xbmcplugin.addDirectoryItem(addon_handle, url, item, isFolder=True)
    ep_view_toan_cuc()
    xbmcplugin.endOfDirectory(addon_handle)

# Mở số tập của 1 mục trong lịch sử
def mo_lich_su_item(index):
    """Mở một mục trong lịch sử để hiển thị danh sách tập đã xem."""
    xbmc.log(f"[Film Free JSON] mo_lich_su_item: {index}", xbmc.LOGINFO)
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    xbmcplugin.setContent(addon_handle, 'files')
    ds = doc_lich_su()
    if index < 0 or index >= len(ds):
        thong_bao("Film Free JSON", "Mục lịch sử không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
        return
    it = ds[index]
    film_name = it.get('name') or "No Name"
    source_index = it.get('source_index', 0)
    ep_index = it.get('episode_index', 0)
    desc = it.get('description') or ""
    loai = it.get('type') or "single"
    thumb_url = it.get('thumb_url') or ""
    rd = it.get('remote_data')
    ds_tap = []
    try:
        if rd and isinstance(rd, dict) and rd.get('url'):
            headers_call = None
            if isinstance(rd.get('headers'), dict):
                headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list):
                headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
            data = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data.get('sources') or []
            nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
            ds_tap = lay_ds_tap_tu_nguon(nguon)
        else:
            # Nếu không có remote_data, tìm kênh trong playlist gốc
            playlist = tai_du_lieu_json(lay_url_playlist())
            ds_nhom = playlist.get('groups') or playlist.get('items') or []
            kenh_tim = None
            for nhom in ds_nhom:
                ds_kenh = nhom.get('channels') or nhom.get('items') or []
                for kenh in ds_kenh:
                    if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                        kenh_tim = kenh; break
                if kenh_tim:
                    break
            if not kenh_tim:
                ds_kenh2 = playlist.get('channels') or playlist.get('items') or []
                for kenh in ds_kenh2:
                    if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                        kenh_tim = kenh; break
            if not kenh_tim:
                thong_bao("Film Free JSON", "Không tìm lại được nội dung", xbmcgui.NOTIFICATION_ERROR)
                return
            ds_nguon = kenh_tim.get('sources') or []
            nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
            ds_tap = lay_ds_tap_tu_nguon(nguon)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi tải nội dung lịch sử: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi tải nội dung: {e}", xbmcgui.NOTIFICATION_ERROR)
        return
    if not ds_tap:
        thong_bao("Film Free JSON", "Không tìm thấy danh sách tập", xbmcgui.NOTIFICATION_ERROR)
        return
    
    # Liệt kê tất cả các tập
    for j, stream in enumerate(ds_tap):
        ep_playing = it.get('episode_index') or 0
        ep_name = stream.get('name') or f"Tập {j+1}"
        if len(ds_tap) == 1:
            ep_name = "Full"
        item = xbmcgui.ListItem(label=f"{film_name} - {ep_name}")
        if j == ep_playing:
            item = xbmcgui.ListItem(label=f"{film_name} - {ep_name} <- Đang Xem")
        
        info = item.getVideoInfoTag()
        info.setTitle(f"{film_name}")
        info.setPlot(desc)
        
        # setMediaType
        loai_phim = tim_loai_phim(loai)
        info.setMediaType(loai_phim)
        
        # setArt
        if thumb_url:
            item.setArt({'thumb': thumb_url, 'icon': thumb_url, 'poster': thumb_url, 'fanart': thumb_url, 'banner': thumb_url})
        else:
            item.setArt({'thumb': fallback_img, 'icon': fallback_img, 'fanart': fallback_fanart, 'banner': fallback_fanart})
        
        url_play = f"{base_url}?action=play_history_episode&i={index}&e={j}"
        xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=True)
    # ep_view_toan_cuc()
    xbmcplugin.endOfDirectory(addon_handle)

def phat_tu_lich_su(index):
    """Phát tiếp tục từ lịch sử (tiếp tục phim bộ từ tập đang xem dở)."""
    xbmc.log(f"[Film Free JSON] phat_tu_lich_su: {index}", xbmc.LOGINFO)
    ds = doc_lich_su()
    if index < 0 or index >= len(ds):
        thong_bao("Film Free JSON", "Mục lịch sử không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
        return
    it = ds[index]
    if it.get('remote_data'):
        # Nếu có remote_data thì phát phim
        film_name = it.get('name') or "Nội dung"
        desc = it.get('description') or ""
        ep_index = it.get('episode_index', 0)
        xbmc.log(f"[Film Free JSON] episode_index: {ep_index}", xbmc.LOGINFO)
        source_index = it.get('source_index', 0)
        rd = it.get('remote_data')
        ds_tap = []
        try:
            if rd and isinstance(rd, dict) and rd.get('url'):
                headers_call = None
                if isinstance(rd.get('headers'), dict):
                    headers_call = rd.get('headers')
                elif isinstance(rd.get('request_headers'), list):
                    headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
                data = tai_du_lieu_json(rd['url'], headers_call)
                ds_nguon = data.get('sources') or []
                nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
                
                ds_tap = lay_ds_tap_tu_nguon(nguon)
            else:
                playlist = tai_du_lieu_json(lay_url_playlist())
                ds_nhom = playlist.get('groups') or playlist.get('items') or []
                kenh_tim = None
                for nhom in ds_nhom:
                    ds_kenh = nhom.get('channels') or nhom.get('items') or []
                    for kenh in ds_kenh:
                        if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                            kenh_tim = kenh; break
                    if kenh_tim:
                        break
                if not kenh_tim:
                    ds_kenh2 = playlist.get('channels') or playlist.get('items') or []
                    for kenh in ds_kenh2:
                        if not kenh.get('remote_data') and (kenh.get('name') == it.get('name')):
                            kenh_tim = kenh; break
                if not kenh_tim:
                    thong_bao("Film Free JSON", "Không tìm thấy nội dung để phát", xbmcgui.NOTIFICATION_ERROR)
                    return
                ds_nguon = kenh_tim.get('sources') or []
                nguon = ds_nguon[source_index] if source_index < len(ds_nguon) else (ds_nguon[0] if ds_nguon else {})
                
                ds_tap = lay_ds_tap_tu_nguon(nguon)
        except Exception as e:
            xbmc.log(f"[Film Free JSON] Lỗi tải nội dung history: {e}", xbmc.LOGINFO)
            thong_bao("Film Free JSON", f"Lỗi tải nội dung: {e}", xbmcgui.NOTIFICATION_ERROR)
            return
        if not ds_tap:
            thong_bao("Film Free JSON", "Không tìm thấy danh sách tập", xbmcgui.NOTIFICATION_ERROR)
            return
        # Phát playlist từ tập ep_index
        xbmc.log(f"[Film Free JSON] phat_tu_lich_su phim bộ: {film_name}", xbmc.LOGINFO)
        tao_playlist_kodi(ds_tap, film_name, ep_index, desc=desc)
        # if not tao_playlist_kodi(ds_tap, film_name, ep_index, desc=desc):
            # return
    else:
        # Nếu không có remote_data thì không phát phim
        thong_bao("Film Free JSON", "Không tìm thấy URL phát", xbmcgui.NOTIFICATION_ERROR)
        return

def phat_tap_lich_su(index, ep_index):
    """Phát một tập cụ thể từ một mục lịch sử (khi người dùng chọn tập từ lịch sử)."""
    xbmc.log(f"[Film Free JSON] phat_tap_lich_su: {index}, {ep_index}", xbmc.LOGINFO)
    ds = doc_lich_su()
    if index < 0 or index >= len(ds):
        thong_bao("Film Free JSON", "Mục lịch sử không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
        return
    it = ds[index]
    # Cập nhật lịch sử với tập mới được chọn để xem
    it['episode_index'] = ep_index
    it['episode_name'] = f"Tập {ep_index+1}"
    it['timestamp'] = int(time.time())
    ds[index] = it
    ghi_lich_su(ds)
    # Phát tập được chọn
    phat_tu_lich_su(index)

# === Phân tích url tìm kiếm do mỗi nguồn dùng mỗi kiểu khác nhau ===
def get_urlsearchjson(url):
    data = tai_du_lieu_json(url)
    if not isinstance(data, dict):
        return None, None, None, None  # hoặc '', '', '', ''

    search = data.get("search") or {}
    if not isinstance(search, dict):
        return None, None, None, None

    paging = search.get("paging") or {}
    if not isinstance(paging, dict):
        paging = {}

    url_search = search.get("url")
    search_key = search.get("search_key")
    page_key = paging.get("page_key")
    size_key = paging.get("size_key")

    #xbmc.log(f"[Film Free JSON] get_urlsearchjson: {url_search} {search_key} {page_key} {size_key}", xbmc.LOGINFO)
    return url_search, search_key, page_key, size_key

def lay_urlsearch(tu_khoa, trang, kich_thuoc):
    urlnguon = lay_url_playlist()
    obj = get_urlsearchjson(urlnguon)
    base_search = obj[0]
    if not base_search:
        return None
    qs = parse.urlencode({f"{obj[1]}": tu_khoa, f"{obj[2]}": trang, f"{obj[3]}": kich_thuoc})
    url_search = f"{base_search}?{qs}"
    # xbmc.log(f"[Film Free JSON] lay_urlsearch: {url_search}", xbmc.LOGINFO)
    return url_search

# ===== (Các hàm tìm kiếm nếu cần thiết) =====
def mo_ket_qua_tim_kiem(tu_khoa, trang, kich_thuoc):
    """Tìm kiếm và hiển thị kết quả các kênh (phim) theo từ khóa."""
    xbmc.log(f"[Film Free JSON] mo_ket_qua_tim_kiem: {tu_khoa}", xbmc.LOGINFO)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        if not url_search:
            thong_bao("Film Free JSON", f"Nguồn Này Không Hỗ Trợ Tìm Kiếm", xbmcgui.NOTIFICATION_ERROR)
            return
        
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or \
                      (isinstance(data.get('groups'), list) and len(data.get('groups')) > 0 and \
                       isinstance(data.get('groups')[0], dict) and \
                       data.get('groups')[0].get('channels')) or \
                      []
        # === DONATE ====
        media_path = os.path.join(addon_path, 'resources', 'media')
        item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
        item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
        info_donate = item_donate.getVideoInfoTag()
        info_donate.setTitle("[Xin ủng hộ Tác giả]")
        info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
        
        # Home
        item_home = xbmcgui.ListItem(label="<<< Quay về Trang chủ <<<", label2="Trở về màn hình chính của addon")
        img_home = os.path.join(media_path, 'icon_home.png')
        item_home.setArt({'thumb': img_home, 'logo': img_home, 'poster': img_home, 'fanart': fallback_fanart, 'banner': fallback_fanart})
        info_home = item_home.getVideoInfoTag()
        info_home.setTitle("<<< Quay về Trang chủ <<<")
        info_home.setPlot("Quay trở lại màn hình chính.")
        xbmcplugin.addDirectoryItem(addon_handle, base_url, item_home, isFolder=True)
        
        # Tiêu đề kết quả
        item_title_text = f"Kết quả tìm kiếm: “{tu_khoa}” (Trang {trang})"
        if not ds_kenh:
            item_title_text = f"Không tìm thấy: {tu_khoa}"
        item_title = xbmcgui.ListItem(label=item_title_text)
        img_item_title = tao_hinh_placeholder(item_title_text,IMAGE_GENERATOR_SEARCH_RESULT)
        item_title.setArt({'thumb': img_item_title, 'icon': img_item_title, 'poster': img_item_title, 'fanart': fallback_fanart, 'banner': fallback_fanart})
        info_item = item_title.getVideoInfoTag()
        info_item.setTitle(item_title_text)
        xbmcplugin.addDirectoryItem(addon_handle, base_url, item_title, isFolder=False)
        # Danh sách kết quả
        for idx, kenh in enumerate(ds_kenh):
            ten_kenh = kenh.get('name') or kenh.get('title') or f"Item {idx+1}"
            loai = (kenh.get('type') or '').lower()
            logo = None
            if isinstance(kenh.get('image'), str):
                logo = kenh['image']
            elif isinstance(kenh.get('image'), dict):
                logo = kenh['image'].get('url')
            if not logo:
                logo = kenh.get('logo')
            desc = kenh.get('description') or ""
            item = xbmcgui.ListItem(label=ten_kenh, label2=desc)
            info = item.getVideoInfoTag()
            info.setTitle(ten_kenh)
            
            # setMediaType
            loai_phim = tim_loai_phim(loai)
            info.setMediaType(loai_phim)
            
            # setArt
            if logo:
                item.setArt({'thumb': logo, 'icon': logo})
            else:
                item.setArt({'thumb': fallback_img, 'icon': fallback_img})
                
            # setPlot
            if desc:
                info.setPlot(desc)
                #item.setInfo('video', {'title': ten_kenh, 'plot': desc})
            co_stream_truc_tiep = bool(kenh.get('stream') or kenh.get('streams'))
            co_remote = bool(kenh.get('remote_data') or kenh.get('remoteData'))
            if co_stream_truc_tiep and not co_remote and not kenh.get('sources'):
                item.setProperty('IsPlayable', 'true')
                url_play = f"{base_url}?action=play_direct_search&q={tu_khoa}&p={trang}&s={kich_thuoc}&idx={idx}"
                xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=False)
            elif co_remote or kenh.get('sources'):
                url_open = f"{base_url}?action=open_channel_search&q={tu_khoa}&p={trang}&s={kich_thuoc}&idx={idx}"
                xbmcplugin.addDirectoryItem(addon_handle, url_open, item, isFolder=True)
            else:
                xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)
        # Nếu còn trang sau, thêm mục "Trang sau"
        page_info = (data.get('load_more') or {}).get('pageInfo') or {}
        current_page = int(page_info.get('current_page') or trang)
        last_page = int(page_info.get('last_page') or current_page)
        if current_page < last_page:
            item_next = xbmcgui.ListItem(label=f"Trang sau ({current_page+1}/{last_page})")
            img_item_next = tao_hinh_placeholder(f"Trang sau ({current_page+1}/{last_page})", IMAGE_GENERATOR_NEXTPAGE)
            item_next.setArt({'thumb': img_item_next, 'icon': img_item_next})
            info_item_next = item_next.getVideoInfoTag()
            info_item_next.setTitle(f"Trang sau ({current_page+1}/{last_page})")
            # info_item_next.setPlot("")
            url_next = f"{base_url}?action=search_next&q={tu_khoa}&p={current_page+1}&s={kich_thuoc}"
            xbmcplugin.addDirectoryItem(addon_handle, url_next, item_next, isFolder=True)
            
        ep_view_toan_cuc()
        xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi tìm kiếm: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi tìm kiếm: {e}", xbmcgui.NOTIFICATION_ERROR)

def mo_channel_tim_kiem(tu_khoa, trang, kich_thuoc, idx):
    """Mở kênh tìm kiếm (có remote_data) và liệt kê các nguồn."""
    xbmc.log(f"[Film Free JSON] mo_channel_tim_kiem: {tu_khoa}", xbmc.LOGINFO)
    xbmcplugin.setContent(addon_handle, 'files')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or \
                      (isinstance(data.get('groups'), list) and len(data.get('groups')) > 0 and \
                       isinstance(data.get('groups')[0], dict) and \
                       data.get('groups')[0].get('channels')) or \
                      []
        if idx < 0 or idx >= len(ds_kenh):
            thong_bao("Film Free JSON", "Mục không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        kenh = ds_kenh[idx]
        loai = (kenh.get('type') or '').lower()
        ten_kenh = kenh.get('name') or kenh.get('title') or f"Channel {idx+1}"
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if not rd or not rd.get('url'):
            thong_bao("Film Free JSON", "Không có dữ liệu chi tiết", xbmcgui.NOTIFICATION_ERROR)
            return
        headers_call = None
        if isinstance(rd.get('headers'), dict):
            headers_call = rd.get('headers')
        elif isinstance(rd.get('request_headers'), list):
            headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
        jrd = tai_du_lieu_json(rd['url'], headers_call)
        ds_nguon = jrd.get('sources') or []
        if not ds_nguon:
            thong_bao("Film Free JSON", "Nguồn không có 'sources'", xbmcgui.NOTIFICATION_ERROR)
            return
        for i, nguon in enumerate(ds_nguon):
            ten = nguon.get('name') or nguon.get('id') or f"Source {i+1}"
            thumb_url = kenh.get('image').get('url') or ""
            desc = kenh.get('description') or ""
            item = xbmcgui.ListItem(label=f"{ten_kenh} - {ten}")
            info = item.getVideoInfoTag()
            info.setTitle(f"{ten_kenh} - {ten}")
            info.setPlot(desc)
            
            # setMediaType
            loai_phim = tim_loai_phim(loai)
            info.setMediaType(loai_phim)
            
            # setArt
            if thumb_url:
                item.setArt({'thumb': thumb_url, 'icon': thumb_url, 'poster': thumb_url, 'fanart': thumb_url, 'banner': thumb_url})
                
            else:
                item.setArt({'thumb': fallback_img, 'icon': fallback_img})
            url_mo = f"{base_url}?action=open_source_search&q={tu_khoa}&p={trang}&s={kich_thuoc}&idx={idx}&src={i}"
            xbmcplugin.addDirectoryItem(addon_handle, url_mo, item, isFolder=True)
        
        xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mở kênh tìm kiếm: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi mở nội dung tìm kiếm: {e}", xbmcgui.NOTIFICATION_ERROR)

def mo_source_tim_kiem(tu_khoa, trang, kich_thuoc, idx, src):
    """Mở một nguồn cụ thể từ kết quả tìm kiếm và hiển thị/phát các tập."""
    xbmc.log(f"[Film Free JSON] mo_source_tim_kiem: {tu_khoa}", xbmc.LOGINFO)
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or \
                      (isinstance(data.get('groups'), list) and len(data.get('groups')) > 0 and \
                       isinstance(data.get('groups')[0], dict) and \
                       data.get('groups')[0].get('channels')) or \
                      []
        if idx < 0 or idx >= len(ds_kenh):
            thong_bao("Film Free JSON", "Mục không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        kenh = ds_kenh[idx]
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if not rd or not rd.get('url'):
            thong_bao("Film Free JSON", "Không có dữ liệu chi tiết", xbmcgui.NOTIFICATION_ERROR)
            return
        headers_call = None
        if isinstance(rd.get('headers'), dict):
            headers_call = rd.get('headers')
        elif isinstance(rd.get('request_headers'), list):
            headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
        jrd = tai_du_lieu_json(rd['url'], headers_call)
        ds_nguon = jrd.get('sources') or []
        if src < 0 or src >= len(ds_nguon):
            thong_bao("Film Free JSON", "Source không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        # Lấy danh sách tập từ nguồn
        nguon = ds_nguon[src]
        nguon_name = nguon.get('name') or ""
        ds_tap = []
        ds_tap = lay_ds_tap_tu_nguon(nguon)
        if not ds_tap:
            thong_bao("Film Free JSON", "Nguồn không có tập", xbmcgui.NOTIFICATION_ERROR)
            return
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        if len(ds_tap) == 1:
            # 1 tập -> phát bằng tao_playlist_kodi luôn
            # Lưu lịch sử:
            muc_ls = {
                "name": film_name,
                "thumb_url":thumb_url,
                "description":desc,
                "timestamp": int(time.time()),
                "type": "series",
                "source_index": src,
                "source_name": nguon_name,
                "episode_index": 0,
                "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
            }
            if rd and rd.get('url'):
                muc_ls["remote_data"] = rd
            try:
                preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
            except:
                preset_idx = 0
            preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
            muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
            luu_lich_su(muc_ls)
            tao_playlist_kodi(ds_tap, film_name, start_index=0)
        else:
            # Nhiều tập -> phát bằng tao_playlist_kodi từ tập 1
            muc_ls = {
                "name": film_name,
                "thumb_url":thumb_url,
                "description":desc,
                "timestamp": int(time.time()),
                "type": "series",
                "source_index": src,
                "source_name": nguon_name,
                "episode_index": 0,
                "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
            }
            if rd and rd.get('url'):
                muc_ls["remote_data"] = rd
            try:
                preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
            except:
                preset_idx = 0
            preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
            muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
            luu_lich_su(muc_ls)
            tao_playlist_kodi(ds_tap, film_name, start_index=0)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mở source tìm kiếm: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi liệt kê tập: {e}", xbmcgui.NOTIFICATION_ERROR)

def phat_truc_tiep_tim_kiem(tu_khoa, trang, kich_thuoc, idx):
    """Phát trực tiếp một kết quả tìm kiếm (phim lẻ)."""
    xbmc.log(f"[Film Free JSON] phat_truc_tiep_tim_kiem: {tu_khoa}", xbmc.LOGINFO)
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or \
                      (isinstance(data.get('groups'), list) and len(data.get('groups')) > 0 and \
                       isinstance(data.get('groups')[0], dict) and \
                       data.get('groups')[0].get('channels')) or \
                      []
        if idx < 0 or idx >= len(ds_kenh):
            thong_bao("Film Free JSON", "Mục không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        kenh = ds_kenh[idx]
        # Lấy link trực tiếp
        st = kenh.get('stream')
        ds_streams = []
        if not st:
            ds_streams = kenh.get('streams') or []
            st = ds_streams[0] if ds_streams else None
        if not st:
            thong_bao("Film Free JSON", "Không tìm thấy luồng phát", xbmcgui.NOTIFICATION_ERROR)
            return
        stream_url = st.get('url')
        headers = st.get('headers') or chuyen_headers_sang_dict(st.get('request_headers'))
        if not stream_url:
            thong_bao("Film Free JSON", "Không tìm thấy URL phát", xbmcgui.NOTIFICATION_ERROR)
            return
        url_kodi = them_header_vao_url(stream_url, headers)
        # Lưu lịch sử xem
        ten = kenh.get('name') or kenh.get('title') or "Nội dung"
        loai = (kenh.get('type') or '').lower()
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        muc_ls = {
                "name": ten,
                "thumb_url":thumb_url,
                "description":desc,
                "timestamp": int(time.time()),
                "type": loai,
                "source_index": 0,
                "episode_index": 0,
                "episode_total": len(ds_streams),
                "episode_name": ds_streams[0].get('name') or "Tập 1"
            }
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            muc_ls["remote_data"] = rd
        muc_ls["source_index"] = 0
        try:
            preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
        except:
            preset_idx = 0
        preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
        muc_ls["url_kodi"] = url_kodi
        luu_lich_su(muc_ls)
        item = xbmcgui.ListItem(path=url_kodi)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=item)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi play tìm kiếm: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi phát: {e}", xbmcgui.NOTIFICATION_ERROR)

def phat_tap_tim_kiem(tu_khoa, trang, kich_thuoc, idx, chiso_nguon, chiso_tap):
    """Phát một tập phim bộ từ kết quả tìm kiếm."""
    xbmc.log(f"[Film Free JSON] phat_tap_tim_kiem: {tu_khoa}", xbmc.LOGINFO)
    try:
        url_search = lay_urlsearch(tu_khoa, trang, kich_thuoc)
        data = tai_du_lieu_json(url_search)
        ds_kenh = data.get('channels') or \
                      (isinstance(data.get('groups'), list) and len(data.get('groups')) > 0 and \
                       isinstance(data.get('groups')[0], dict) and \
                       data.get('groups')[0].get('channels')) or \
                      []
        if idx < 0 or idx >= len(ds_kenh):
            thong_bao("Film Free JSON", "Mục không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        kenh = ds_kenh[idx]
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        headers_call = None
        if rd and rd.get('url'):
            if isinstance(rd.get('headers'), dict):
                headers_call = rd.get('headers')
            elif isinstance(rd.get('request_headers'), list):
                headers_call = chuyen_headers_sang_dict(rd.get('request_headers'))
        else:
            thong_bao("Film Free JSON", "Không có dữ liệu chi tiết", xbmcgui.NOTIFICATION_ERROR)
            return
        jrd = tai_du_lieu_json(rd['url'], headers_call)
        ds_nguon = jrd.get('sources') or []
        if chiso_nguon < 0 or chiso_nguon >= len(ds_nguon):
            thong_bao("Film Free JSON", "Source không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        nguon = ds_nguon[chiso_nguon]
        ds_tap = []
        contents = nguon.get('contents')
        if isinstance(contents, list):
            for content in contents:
                for stream in (content.get('streams') or []):
                    ds_tap.append(stream)
        elif isinstance(contents, dict):
            for stream in (contents.get('streams') or []):
                ds_tap.append(stream)
        if not ds_tap:
            for stream in (nguon.get('streams') or []):
                ds_tap.append(stream)
        if chiso_tap < 0 or chiso_tap >= len(ds_tap):
            thong_bao("Film Free JSON", "Tập không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return
        ds_link = ds_tap[chiso_tap].get('stream_links') or []
        if not ds_link:
            thong_bao("Film Free JSON", "Không tìm thấy link phát", xbmcgui.NOTIFICATION_ERROR)
            return
        # Chọn link tốt nhất
        url_phat = None; headers = None
        for link in ds_link:
            if (link.get('type') or '').lower() == 'hls':
                url_phat = link.get('url')
                headers = link.get('headers') or chuyen_headers_sang_dict(link.get('request_headers'))
                # Ưu tiên HLS NoAds
                if 'no ads' in (link.get('name') or '').lower() or 'noads' in (link.get('name') or '').lower():
                    break
        if not url_phat:
            link = ds_link[0]
            url_phat = link.get('url')
            headers = link.get('headers') or chuyen_headers_sang_dict(link.get('request_headers'))
        if not url_phat:
            thong_bao("Film Free JSON", "Không tìm thấy link phát", xbmcgui.NOTIFICATION_ERROR)
            return
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        loai = (kenh.get('type') or '').lower()
        ep_name = ds_tap[chiso_tap].get('name') or f"Tập {chiso_tap+1}"
        url_kodi = them_header_vao_url(url_phat, headers)
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        # Lưu lịch sử xem phim bộ (tìm kiếm)
        muc_ls = {
            "name": film_name,
            "thumb_url":thumb_url,
            "description":desc,
            "timestamp": int(time.time()),
            "type": loai,
            "source_index": chiso_nguon,
            "episode_index": chiso_tap,
            "episode_total": len(ds_tap),
            "episode_name": ep_name,
            "url_kodi": url_kodi
        }
        if rd and rd.get('url'):
            muc_ls["remote_data"] = rd
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[0][0]  # gán tạm theo nguồn hiện tại (0)
        luu_lich_su(muc_ls)
        item = xbmcgui.ListItem(path=url_kodi)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=item)
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi phát tập tìm kiếm: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi phát: {e}", xbmcgui.NOTIFICATION_ERROR)

# Logic lấy ds_link từ một tập (episode) Logic này được lặp lại trong tao_playlist_kodi phat_tap
def lay_ds_link_tu_tap(episode):
    """Lấy danh sách stream_links từ một tập, xử lý remote_data nếu cần."""
    # xbmc.log(f"[Film Free JSON] lay_ds_link_tu_tap: {episode}", xbmc.LOGINFO)
    ds_link = episode.get('stream_links') or []
    if not ds_link:
        rd_ep = episode.get('remote_data') or episode.get('remoteData')
        if rd_ep and rd_ep.get('url'):
            headers_ep = chuyen_headers_sang_dict(rd_ep.get('headers') or rd_ep.get('request_headers'))
            try:
                ep_data = tai_du_lieu_json(rd_ep['url'], headers_ep)
                if isinstance(ep_data, dict):
                    ds_link = ep_data.get('stream_links') or ep_data.get('links') or []
                    if not ds_link and ep_data.get('url'):
                        ds_link = [ep_data]
                elif isinstance(ep_data, list):
                    ds_link = ep_data
            except Exception as e:
                xbmc.log(f"[Film Free JSON] Lỗi tải remote_data tập: {e}", xbmc.LOGINFO)
                ds_link = []
    return ds_link

# Logic lấy ds_tap từ một nguồn (source) Logic này lặp lại ở mo_kenh, mo_nguon, mo_lich_su_item, phat_tu_lich_su, mo_source_tim_kiem
def lay_ds_tap_tu_nguon(nguon):
    """Gom danh sách tập (streams) từ một đối tượng nguồn."""
    ds_tap = []
    contents = nguon.get('contents')
    if isinstance(contents, list):
        for content in contents:
            ds_tap.extend(content.get('streams') or [])
    elif isinstance(contents, dict):
        ds_tap.extend(contents.get('streams') or [])
    
    if not ds_tap:
        # Fallback nếu 'contents' không có gì, thử 'streams' ở cấp nguồn
        ds_tap.extend(nguon.get('streams') or [])
    return ds_tap

# Logic chọn link (HLS + NoAds) Logic này lặp lại trong tao_playlist_kodi và phat_tap
def chon_link_tot_nhat(ds_link):
    """Chọn link tốt nhất từ danh sách, ưu tiên HLS, NoAds. Trả về link_dict hoặc None."""
    if not ds_link:
        return None

    def la_noads(name: str) -> bool:
        n = (name or "").lower()
        return ('no ads' in n) or ('noads' in n) or ('không quảng cáo' in n)

    ds_hls = [l for l in ds_link if (l.get('type') or '').lower() == 'hls']
    if ds_hls:
        ds_hls_noads = [l for l in ds_hls if la_noads(l.get('name'))]
        ds_uutien = ds_hls_noads + [l for l in ds_hls if l not in ds_hls_noads]
    else:
        ds_noads = [l for l in ds_link if la_noads(l.get('name'))]
        ds_uutien = ds_noads + [l for l in ds_link if l not in ds_noads]

    # Trả về link đầu tiên có url
    for link in ds_uutien:
        if link.get('url'):
            return link
    
    # Nếu không có link nào trong ds_uutien (ví dụ ds_link rỗng), thử lại từ ds_link gốc
    if not ds_uutien:
         for link in ds_link:
            if link.get('url'):
                return link

    return None

def hien_thi_ds_nguon_khac():
    """Hiển thị danh sách các nguồn (DANH_SACH_NGUON) để chuyển đổi."""
    xbmc.log(f"[Film Free JSON] hien_thi_ds_nguon_khac", xbmc.LOGINFO)
    xbmcplugin.setContent(addon_handle, 'files')
    try:
        addon = xbmcaddon.Addon()
        addon_path = addon.getAddonInfo('path')
        nguon_media_path = os.path.join(addon_path, 'resources', 'media', 'nguon')

        # 1. Lấy URL đang hoạt động và URL custom
        custom_url = (addon.getSetting("custom_source") or "").strip()
        active_url = (addon.getSetting("active_source_url") or "").strip()
        
        # Nếu custom_url đang được dùng, nó là "active"
        url_dang_chon = custom_url if custom_url else active_url
        
        # === DONATE ====
        media_path = os.path.join(addon_path, 'resources', 'media')
        item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
        item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
        info_donate = item_donate.getVideoInfoTag()
        info_donate.setTitle("[Xin ủng hộ Tác giả]")
        info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
        
        # 2. Lặp qua danh sách nguồn (DANH_SACH_NGUON đã tải)
        # for idx, (ma, url, img, desc) in enumerate(DANH_SACH_NGUON):
        for idx, (ma, url, img, desc) in enumerate(lay_ds_nguon_da_tai()):
            
            ten_nguon = ma.upper()
            logo_path = img # Dùng thẳng link ảnh từ JSON
            
            # (Bạn có thể giữ logic logo local nếu muốn)
            logo_path_custom = os.path.join(nguon_media_path, f"custom.png") 

            # So sánh URL (đã loại bỏ khoảng trắng)
            is_active = (url and (url.strip() == url_dang_chon))

            if ma == "custom":
                # Xử lý mục "Custom" đặc biệt
                item_label = "[Nguồn Tùy Chỉnh (Settings)]"
                if custom_url:
                     item_label = f"▶ [Nguồn Tùy Chỉnh] (Đang dùng)"
                item = xbmcgui.ListItem(label=item_label, label2="Nguồn tùy chỉnh của bạn")
                item.setArt({'thumb': logo_path_custom, 'icon': logo_path_custom})
                info = item.getVideoInfoTag()
                info.setTitle(item_label)
                info.setPlot("Nguồn tùy chỉnh của bạn")
                # Mở trang Cài đặt (Settings) của addon
                url_settings = f"{base_url}?action=open_kodi_settings"
                # url_settings = f"xbmc.RunPlugin(plugin://{xbmcaddon.Addon().getAddonInfo('id')}/?action=settings)"
                xbmcplugin.addDirectoryItem(addon_handle, url_settings, item, isFolder=False)
            
            elif is_active:
                # Đánh dấu nguồn đang hoạt động
                item = xbmcgui.ListItem(label=f"▶ {ten_nguon} (Đang dùng)", label2=desc)
                item.setArt({'thumb': logo_path, 'icon': logo_path}) 
                info = item.getVideoInfoTag()
                info.setTitle(ten_nguon)
                info.setPlot(desc)
                xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)
            
            else:
                # Tạo item để chuyển đổi
                item = xbmcgui.ListItem(label=f"Chuyển sang: {ten_nguon}", label2=desc)
                item.setArt({'thumb': logo_path, 'icon': logo_path})
                info = item.getVideoInfoTag()
                info.setTitle(ten_nguon)
                info.setPlot(desc)
                url_set = f"{base_url}?action=set_nguon&new_idx={idx}"
                xbmcplugin.addDirectoryItem(addon_handle, url_set, item, isFolder=False)
                
        xbmcplugin.endOfDirectory(addon_handle)
        
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi hien_thi_ds_nguon_khac: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi hiển thị nguồn: {e}", xbmcgui.NOTIFICATION_ERROR)

def dat_nguon_moi(new_idx):
    """Lưu URL của nguồn mới vào settings và làm mới Kodi."""
    xbmc.log(f"[Film Free JSON] dat_nguon_moi: {new_idx}", xbmc.LOGINFO)
    try:
        # 1. Kiểm tra chỉ số hợp lệ (so với DANH_SACH_NGUON đã tải)
        if new_idx < 0 or new_idx >= len(lay_ds_nguon_da_tai()):
            thong_bao("Film Free JSON", "Chỉ số nguồn không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return

        # 2. Lấy thông tin nguồn mới
        (ma, url_moi, img, desc) = lay_ds_nguon_da_tai()[new_idx]
        ten_nguon_moi = ma.upper()

        if not url_moi:
             thong_bao("Film Free JSON", "Nguồn này không có URL", xbmcgui.NOTIFICATION_ERROR)
             return

        # 3. Lưu cài đặt mới
        addon = xbmcaddon.Addon()
        
        # === THAY ĐỔI QUAN TRỌNG ===
        # LƯU URL MỚI VÀO 'active_source_url'
        addon.setSetting("active_source_url", url_moi)
        # XÓA NGUỒN CUSTOM (để ưu tiên ở lay_url_playlist hoạt động)
        addon.setSetting("custom_source", "")
        # === HẾT THAY ĐỔI ===

        # 4. Thông báo cho người dùng
        thong_bao("Film Free JSON", f"Đã chuyển nguồn sang: {ten_nguon_moi}. Đang tải lại...")

        # 5. Yêu cầu Kodi làm mới (reload) thư mục gốc của addon
        xbmc.executebuiltin(f"Container.Update({base_url})")

    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi dat_nguon_moi: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi đổi nguồn: {e}", xbmcgui.NOTIFICATION_ERROR)

def open_kodi_settings():
    """Chỉ thực thi lệnh mở Settings và dừng lại."""
    try:
        addon_id = xbmcaddon.Addon().getAddonInfo('id')
        xbmc.executebuiltin(f"Addon.OpenSettings({addon_id})")
        # Báo cho Kodi là đã thành công, nhưng không trả về danh sách
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True) 
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mở settings: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi mở Cài đặt: {e}", xbmcgui.NOTIFICATION_ERROR)

def tim_loai_phim(loai):
    loai_phim = 'movie'
    if loai == 'single':
        return loai_phim
    elif loai == 'series':
        loai_phim = 'tvshow'
        return loai_phim
    elif loai == 'playlist':
        loai_phim = 'tvshow'
        return loai_phim
    else:
        return loai_phim

def lay_ds_nguon_da_tai():
    """
    Hàm "Getter" để tải lười (lazy load) DANH_SACH_NGUON.
    Chỉ tải từ URL vào lần đầu tiên được gọi.
    """
    global _DANH_SACH_NGUON_CACHE
    
    # 1. Nếu đã tải rồi, trả về cache ngay lập tức
    if _DANH_SACH_NGUON_CACHE is not None:
        return _DANH_SACH_NGUON_CACHE
        
    # 2. Nếu chưa tải (lần gọi đầu tiên), thực hiện tải
    xbmc.log("[Film Free JSON] Lần đầu tiên, bắt đầu tải DANH_SACH_NGUON...", xbmc.LOGINFO)
    try:
        # === THAY ĐỔI Ở ĐÂY: Lấy URL động từ hàm mới ===
        url_dong = lay_url_remote_config()
        
        ds_nguon = tai_danh_sach_nguon(url_dong, DANH_SACH_NGUON_MACDINH)
        _DANH_SACH_NGUON_CACHE = ds_nguon
        return _DANH_SACH_NGUON_CACHE
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi nghiêm trọng khi tải lười DS NGUON: {e}", xbmc.LOGERROR)
        # Nếu lỗi, dùng tạm danh sách mặc định để addon không bị sập
        _DANH_SACH_NGUON_CACHE = DANH_SACH_NGUON_MACDINH
        return _DANH_SACH_NGUON_CACHE
        
# ===== HÀM TRỢ GIÚP MỚI ĐỂ TÌM SỐ MÙA CÓ TRONG TÊN PHIM =====
def tim_so_mua(ten_phim):
    """
    Sử dụng Regex để tìm số Mùa (Season) từ tên phim.
    Ví dụ: "Phim (Mùa 3)" -> 3
    """
    if not ten_phim:
        return None
        
    # Mẫu regex này sẽ tìm (Phần|Mùa|Season) + (khoảng trắng) + (1 hoặc 2 chữ số)
    # re.IGNORECASE là để không phân biệt hoa/thường (ví dụ: 'season' hay 'Season')
    pattern = re.compile(r'(Phần|Mùa|Season)\s*(\d{1,2})', re.IGNORECASE)
    
    match = pattern.search(ten_phim)
    
    if match:
        try:
            # group(2) là nhóm chứa chữ số (ví dụ: '3')
            return int(match.group(2))
        except ValueError:
            return None
    
    # Nếu không tìm thấy, trả về None
    return None

def mo_xem_them():
    """
    (Hàm mới)
    Tạo một menu "phẳng" bằng cách trích xuất tất cả các mục 'radio'
    từ cấu trúc 'sorts' trong JSON.
    """
    xbmc.log("[Film Free JSON] mo_xem_them", xbmc.LOGINFO)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    try:
        # === DONATE ====
        media_path = os.path.join(addon_path, 'resources', 'media')
        item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
        item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
        info_donate = item_donate.getVideoInfoTag()
        info_donate.setTitle("[Xin ủng hộ Tác giả]")
        info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
        # === END DONATE ====
        
        playlist = tai_du_lieu_json(lay_url_playlist())
        ds_sorts = playlist.get('sorts')
        if not ds_sorts or not isinstance(ds_sorts, list):
            thong_bao("Film Free JSON", "Nguồn này không hỗ trợ", xbmcgui.NOTIFICATION_ERROR)
            return

        flat_list = [] # Danh sách
        
        # Lặp qua các mục cấp 1
        for sort_item in ds_sorts:
            item_type = sort_item.get('type')
            
            if item_type == 'radio':
                # Nếu là radio, thêm thẳng vào
                flat_list.append(sort_item) 
            elif item_type == 'dropdown':
                # Nếu là dropdown, lặp qua các mục con 'value'
                value_array = sort_item.get('value')
                if isinstance(value_array, list):
                    for sub_item in value_array:
                        # Chỉ lấy các mục con là 'radio'
                        if sub_item.get('type') == 'radio':
                            flat_list.append(sub_item)
        
        if not flat_list:
            thong_bao("Film Free JSON", "Không tìm thấy mục 'radio' nào", xbmcgui.NOTIFICATION_ERROR)
            return
            
        # Bây giờ, tạo các mục menu từ danh sách phẳng
        for item_data in flat_list:
            text = item_data.get('text')
            url = item_data.get('url')
            
            if not text or not url:
                continue
            
            item = xbmcgui.ListItem(label=text)
            img_text = tao_hinh_placeholder(text)
            item.setArt({'thumb': img_text, 'icon': img_text, 'poster': img_text, 'fanart': fallback_fanart, 'banner': fallback_fanart})
            info_item = item.getVideoInfoTag()
            info_item.setTitle(text)
            # Tạo action để gọi hàm tải trang (bắt đầu từ trang 1)
            # Chúng ta chỉ cần truyền 'url' gốc và 'page'
            url_action = f"{base_url}?action=tai_danh_sach_phan_trang&url={parse.quote_plus(url)}&page=1"
            xbmcplugin.addDirectoryItem(addon_handle, url_action, item, isFolder=True)
            
        ep_view_toan_cuc()
        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mo_xem_them: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi tạo menu 'Xem thêm': {e}", xbmcgui.NOTIFICATION_ERROR)

def tai_danh_sach_phan_trang():
    """
    (Hàm cửa ngõ - ĐÃ SỬA LỖI)
    Tải một trang danh sách và gọi hàm hiển thị MỚI.
    """
    xbmc.log("[Film Free JSON] tai_danh_sach_phan_trang", xbmc.LOGINFO)
    try:
        # 1. Lấy tham số từ URL
        base_url_str = parse.unquote(args.get('url')) # URL gốc (ví dụ: .../tab/phim-bo)
        page = int(args.get('page', '1'))
        
        page_key = args.get('page_key', 'p')
        size_key = args.get('size_key', 's')
        
        # 2. Tạo URL đầy đủ để tải (với size=10 theo yêu cầu)
        url_parts = list(parse.urlsplit(base_url_str))
        query = dict(parse.parse_qsl(url_parts[3]))
        
        query[page_key] = page
        query[size_key] = SET_SIZE_KEY  # <-- Đặt SET_SIZE_KEY số lượng là 15
        
        url_parts[3] = parse.urlencode(query)
        url_to_load = parse.urlunsplit(url_parts)
        
        xbmc.log(f"[Film Free JSON] Đang tải URL phân trang: {url_to_load}", xbmc.LOGINFO)
        
        # 3. Tải dữ liệu
        data = tai_du_lieu_json(url_to_load)
        ds_kenh = data.get('channels')
        
        if not ds_kenh or not isinstance(ds_kenh, list):
            thong_bao("Film Free JSON", "Không có nội dung hoặc lỗi định dạng", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle) # Phải kết thúc thư mục
            return

        # 4. GỌI HÀM HIỂN THỊ MỚI (KHÔNG TÁI SỬ DỤNG HÀM CŨ)
        hien_thi_kenh_theo_xem_them(
            ds_kenh, 
            url_to_load, 
            base_url_str, 
            data.get('load_more')
        )
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi tai_danh_sach_phan_trang: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi tải danh sách phân trang: {e}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle) # Đảm bảo kết thúc nếu có lỗi

def hien_thi_kenh_theo_xem_them(ds_kenh, url_da_tai, url_goc, load_more_data, home=False):
    """
    (HÀM MỚI - GIỐNG hien_thi_kenh_theo_danh_sach)
    Hàm này hiển thị danh sách phim từ "Xem thêm".
    Nó tạo ra các action URL MỚI (play_xem_them, open_xem_them).
    Nó tự xử lý "Trang sau" và "endOfDirectory".
    """
    xbmc.log(f"[Film Free JSON] hien_thi_kenh_theo_xem_them: {len(ds_kenh)} phim", xbmc.LOGINFO)
    # 1. Báo cho skin (giữ nguyên)
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    media_path = os.path.join(addon_path, 'resources', 'media')
    
    if home == False:
        
        # Home
        item_home = xbmcgui.ListItem(label="<<< Quay về Trang chủ <<<", label2="Trở về màn hình chính của addon")
        img_home = os.path.join(media_path, 'icon_home.png')
        item_home.setArt({'thumb': img_home, 'logo': img_home, 'poster': img_home, 'fanart': fallback_fanart, 'banner': fallback_fanart})
        info_home = item_home.getVideoInfoTag()
        info_home.setTitle("<<< Quay về Trang chủ <<<")
        info_home.setPlot("Quay trở lại màn hình chính (danh sách nhóm).")
        xbmcplugin.addDirectoryItem(addon_handle, base_url, item_home, isFolder=True)
        
        # 2. Thêm mục Donate (giữ nguyên)
        item_donate = xbmcgui.ListItem(label="[Xin ủng hộ Tác giả]", label2="Quét mã QR để ủng hộ")
        item_donate.setArt({'thumb': os.path.join(media_path, 'QR_Donate.jpg')}) 
        info_donate = item_donate.getVideoInfoTag()
        info_donate.setTitle("[Xin ủng hộ Tác giả]")
        info_donate.setPlot("Cảm ơn bạn đã sử dụng addon! Hãy quét mã QR để ủng hộ tác giả một ly cafe và dùng để duy trì nguồn.")
        xbmcplugin.addDirectoryItem(addon_handle, f"{base_url}?action=show_donate", item_donate, isFolder=False)
    
    # 3. Lặp qua danh sách kênh (giống hệt code cũ)
    for idx, kenh in enumerate(ds_kenh):
        loai = (kenh.get('type') or '').lower()
        ten_kenh = kenh.get('name') or kenh.get('title') or f"Channel {idx+1}"
        logo = None
        
        if loai in ('ad', 'banner'):
            continue
            
        if isinstance(kenh.get('image'), str):
            logo = kenh['image']
        elif isinstance(kenh.get('image'), dict):
            logo = kenh['image'].get('url')
        if not logo:
            logo = kenh.get('logo')
            
        desc = kenh.get('description') or ""
        
        item = xbmcgui.ListItem(label=ten_kenh, label2=desc)
        
        # Art (Chỉ 'thumb' và 'icon' để skin tự tìm)
        art_dict = {}
        if logo:
            art_dict['thumb'] = logo
            art_dict['icon'] = logo
        else:
            art_dict['thumb'] = fallback_img
            art_dict['icon'] = fallback_img
        item.setArt(art_dict)
            
        # InfoTag (luôn gọi)
        info = item.getVideoInfoTag()
        info.setTitle(ten_kenh)
        info.setPlot(desc)
        
        # Lấy ID (để skin tự tìm) một ngày nào đó nguồn json sẽ hỗ trợ tính năng này, hiện tại thì không
        ids_dict = kenh.get('ids')
        if isinstance(ids_dict, dict):
            tmdb_id = ids_dict.get('tmdb')
            if tmdb_id:
                try:
                    info.setUniqueID(str(tmdb_id), 'tmdb') 
                except Exception: pass
            
            imdb_id = ids_dict.get('imdb')
            if imdb_id:
                info.setIMDBNumber(imdb_id)
        
        # Lấy MediaType (dùng hàm tim_loai_phim)
        loai_phim = tim_loai_phim(loai) # 'movie' hoặc 'tvshow'
        info.setMediaType(loai_phim)
        
        # 4. (THAY ĐỔI LỚN) TẠO ACTION URL MỚI
        url_da_tai_encoded = parse.quote_plus(url_da_tai)
        
        if loai_phim == 'movie':
            # PHIM LẺ
            item.setProperty('IsPlayable', 'true')
            url_play = f"{base_url}?action=mo_kenh_xem_them&i={idx}&url={url_da_tai_encoded}"
            xbmcplugin.addDirectoryItem(addon_handle, url_play, item, isFolder=False)
            
        elif loai_phim == 'tvshow':
            # PHIM BỘ
            url_open = f"{base_url}?action=mo_kenh_xem_them&i={idx}&url={url_da_tai_encoded}"
            xbmcplugin.addDirectoryItem(addon_handle, url_open, item, isFolder=True)
            
        else:
            # Loại không xác định (giống logic cũ)
            xbmcplugin.addDirectoryItem(addon_handle, base_url, item, isFolder=False)

    # 5. Xử lý "Trang sau" (Load More)
    if isinstance(load_more_data, dict):
        page_info = load_more_data.get('pageInfo', {})
        current_page = int(page_info.get('current_page', 1))
        last_page = int(page_info.get('last_page', current_page))
        
        next_page = current_page + 1
        
        if next_page <= last_page:
            paging_keys = load_more_data.get('paging', {})
            page_key_next = paging_keys.get('page_key', 'p')
            size_key_next = paging_keys.get('size_key', 's')
            
            name_next = (f"Trang sau ({next_page}/{last_page})")
            item_next = xbmcgui.ListItem(label=name_next)
            img_home = tao_hinh_placeholder(name_next, IMAGE_GENERATOR_NEXTPAGE)
            item_next.setArt({'thumb': img_home, 'logo': img_home, 'poster': img_home, 'fanart': fallback_fanart, 'banner': fallback_fanart})
            info_item_next = item_next.getVideoInfoTag()
            info_item_next.setTitle(name_next)
            info_item_next.setPlot(f"Tới trang {last_page}")
            
            # URL action mới sẽ gọi lại 'tai_danh_sach_phan_trang'
            url_action_next = f"{base_url}?action=tai_danh_sach_phan_trang" \
                              f"&url={parse.quote_plus(url_goc)}" \
                              f"&page={next_page}" \
                              f"&page_key={page_key_next}" \
                              f"&size_key={size_key_next}"
                              
            xbmcplugin.addDirectoryItem(addon_handle, url_action_next, item_next, isFolder=True)
    ep_view_toan_cuc()
    xbmcplugin.endOfDirectory(addon_handle)

def mo_kenh_xem_them():
    """
    (HÀM MỚI)
    Mở phim bộ (tvshow) từ mục "Xem thêm".
    Hàm này tải lại URL danh sách đã phân trang.
    """
    xbmc.log("[Film Free JSON] mo_kenh_xem_them", xbmc.LOGINFO)
    xbmcplugin.setContent(addon_handle, 'files')
    xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
    try:
        # 1. Lấy tham số (URL và chỉ số 'i')
        url_da_tai = parse.unquote(args.get('url'))
        chiso_kenh = int(args.get('i', -1))
        url_da_tai_encoded = parse.quote_plus(url_da_tai)
        
        if not url_da_tai or chiso_kenh == -1:
            thong_bao("Film Free JSON", "Tham số mở không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return

        # 2. Tải lại đúng URL đó
        data = tai_du_lieu_json(url_da_tai)
        ds_kenh = data.get('channels')
        
        if not ds_kenh or not (0 <= chiso_kenh < len(ds_kenh)):
            thong_bao("Film Free JSON", "Lỗi: Không tìm thấy lại kênh", xbmcgui.NOTIFICATION_ERROR)
            return
        
        kenh = ds_kenh[chiso_kenh]
        loai = (kenh.get('type') or '').lower()
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        # 3. Sao chép logic từ 'mo_kenh' (vì nó đã tốt)
        
        # (Lấy remote_data hoặc sources)
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            headers_call = chuyen_headers_sang_dict(rd.get('headers') or rd.get('request_headers'))
            data_kenh = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data_kenh.get('sources') or []
        else:
            ds_nguon = kenh.get('sources') or []
            
        if not ds_nguon:
            thong_bao("Film Free JSON", "Không tìm thấy nguồn phát", xbmcgui.NOTIFICATION_ERROR)
            return
            
        if len(ds_nguon) == 1:
            # Chỉ có 1 nguồn, lấy ds_tap và gọi tao_playlist_kodi
            nguon = ds_nguon[0]
            nguon_name = nguon.get('name') or ""
            ds_tap = lay_ds_tap_tu_nguon(nguon)
            if not ds_tap:
                thong_bao("Film Free JSON", "Nguồn không có tập nào", xbmcgui.NOTIFICATION_ERROR)
                return
            # (Bạn có thể sao chép logic 'luu_lich_su' từ mo_kenh vào đây nếu muốn)
            muc_ls = {
                "name": film_name,
                "thumb_url":thumb_url,
                "description":desc,
                "timestamp": int(time.time()),
                "type": loai,
                "source_index": 0,
                "source_name":nguon_name,
                "episode_index": 0,
                "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
                }
            if rd and rd.get('url'):
                muc_ls["remote_data"] = rd
            try:
                preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
            except:
                preset_idx = 0
            preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
            muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
            luu_lich_su(muc_ls)
            
            tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
            return
            
        else:
            # Nhiều nguồn, hiển thị danh sách nguồn để chọn
            xbmcplugin.setPluginCategory(addon_handle, ADDON_GLOBAL_CATEGORY)
            logo = None
            if isinstance(kenh.get('image'), str):
                logo = kenh['image']
            elif isinstance(kenh.get('image'), dict):
                logo = kenh['image'].get('url')
            if not logo:
                logo = kenh.get('logo')

            art_dict = {}
            if logo:
                art_dict['thumb'] = logo
                art_dict['icon'] = logo
            else:
                art_dict['thumb'] = fallback_img
                art_dict['icon'] = fallback_img

            for i, nguon in enumerate(ds_nguon):
                ten_nguon = nguon.get('name') or f"Nguồn {i+1}"
                
                # Tạo tên: "Tên Phim - [Thuyết minh]"
                item_label = f"{film_name} - [{ten_nguon}]"
                
                item = xbmcgui.ListItem(label=item_label, label2=desc)
                item.setArt(art_dict)
                
                info = item.getVideoInfoTag()
                info.setTitle(item_label)
                info.setPlot(desc)
                info.setMediaType('tvshow')
                
                # Tạo action MỚI (mo_nguon_xem_them)
                # Truyền 'url_da_tai' + 'i' (chiso_kenh) + 's' (chiso_nguon)
                url_action = f"{base_url}?action=mo_nguon_xem_them" \
                             f"&i={chiso_kenh}" \
                             f"&sc={i}" \
                             f"&url={url_da_tai_encoded}"
                             
                xbmcplugin.addDirectoryItem(addon_handle, url_action, item, isFolder=True)
                
            xbmcplugin.endOfDirectory(addon_handle)
            
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mo_kenh_xem_them: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi mở kênh (Xem thêm): {e}", xbmcgui.NOTIFICATION_ERROR)

def mo_nguon_xem_them():
    """
    (HÀM MỚI)
    Xử lý khi người dùng chọn 1 nguồn cụ thể từ 'mo_kenh_xem_them'.
    Hàm này sẽ gọi tao_playlist_kodi.
    """
    xbmc.log("[Film Free JSON] mo_nguon_xem_them", xbmc.LOGINFO)
    try:
        # 1. Lấy tham số (URL, chỉ số kênh 'i', chỉ số nguồn 's')
        url_da_tai = parse.unquote(args.get('url'))
        chiso_kenh = int(args.get('i', -1))
        chiso_nguon = int(args.get('sc', -1))
        
        if not url_da_tai or chiso_kenh == -1 or chiso_nguon == -1:
            thong_bao("Film Free JSON", "Tham số mở nguồn không hợp lệ", xbmcgui.NOTIFICATION_ERROR)
            return

        # 2. Tải lại danh sách kênh
        data = tai_du_lieu_json(url_da_tai)
        ds_kenh = data.get('channels')
        
        if not ds_kenh or not (0 <= chiso_kenh < len(ds_kenh)):
            thong_bao("Film Free JSON", "Lỗi: Không tìm thấy loại kênh", xbmcgui.NOTIFICATION_ERROR)
            return
        
        kenh = ds_kenh[chiso_kenh]
        
        # 3. Lấy đúng nguồn (source)
        rd = kenh.get('remote_data') or kenh.get('remoteData')
        if rd and rd.get('url'):
            headers_call = chuyen_headers_sang_dict(rd.get('headers') or rd.get('request_headers'))
            data_kenh = tai_du_lieu_json(rd['url'], headers_call)
            ds_nguon = data_kenh.get('sources') or []
        else:
            ds_nguon = kenh.get('sources') or []
            
        if not ds_nguon or not (0 <= chiso_nguon < len(ds_nguon)):
            thong_bao("Film Free JSON", "Lỗi: Không tìm thấy loại nguồn", xbmcgui.NOTIFICATION_ERROR)
            return
            
        nguon = ds_nguon[chiso_nguon]
        nguon_name = nguon.get('name') or ""
        
        # 4. Lấy danh sách tập (ds_tap) từ nguồn đó
        ds_tap = lay_ds_tap_tu_nguon(nguon)
        if not ds_tap:
            thong_bao("Film Free JSON", "Nguồn không có tập nào", xbmcgui.NOTIFICATION_ERROR)
            return
        
        film_name = kenh.get('name') or kenh.get('title') or "Nội dung"
        thumb_url = kenh.get('image').get('url') or ""
        desc = kenh.get('description') or ""
        loai = (kenh.get('type') or '').lower()
        # (Bạn có thể sao chép logic 'luu_lich_su' từ mo_nguon vào đây nếu muốn)
        muc_ls = {
                "name": film_name,
                "thumb_url":thumb_url,
                "description":desc,
                "timestamp": int(time.time()),
                "type": loai,
                "source_index": chiso_nguon,
                "source_name":nguon_name,
                "episode_index": 0,
                "episode_total": len(ds_tap),
                "episode_name": ds_tap[0].get('name') or "Tập 1"
            }
        if rd and rd.get('url'):
            muc_ls["remote_data"] = rd
        try:
            preset_idx = int(xbmcaddon.Addon().getSetting("active_source_url") or "0")
        except:
            preset_idx = 0
        preset_idx = max(0, min(preset_idx, len(lay_ds_nguon_da_tai()) - 1))
        muc_ls["source_key"] = lay_ds_nguon_da_tai()[preset_idx][0]
        luu_lich_su(muc_ls)
        
        # 5. Gọi hàm phát playlist
        tao_playlist_kodi(ds_tap, film_name, start_index=0, desc=desc)
        return

    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi mo_nguon_xem_them: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi mở nguồn (Xem thêm): {e}", xbmcgui.NOTIFICATION_ERROR)

def cap_nhat_view_toan_cuc():
    """
    Chạy ngay khi người dùng nhấp chuột (trong main).
    Kiểm tra xem người dùng có đang ở một View khác với View đã lưu không.
    Nếu có -> Cập nhật View Toàn cục.
    """
    try:
        # 1. Lấy ID của control đang focus (Trong skin này, nó thường là View ID)
        window_id = xbmcgui.getCurrentWindowId()
        if not window_id: return
        
        window = xbmcgui.Window(window_id)
        focus_id = window.getFocusId()
        current_view_id = str(focus_id)
        
        # 2. Lọc ID rác (Nút bấm, Menu...)
        # View ID thường nhỏ (50, 51, 500...). ID > 1000 thường là nút.
        if not current_view_id.isdigit() or int(current_view_id) >= 1000:
            return
        
        # Không lưu view mặc định, tránh trường hợp các danh sách setContent = files khi bấm nút quay lại thì tự quay về mặc định
        if not current_view_id.isdigit() or int(current_view_id) <= 50:
            return
        # 3. So sánh với ID đã lưu
        addon = xbmcaddon.Addon()
        saved_view_id = addon.getSetting('global_view_id')
        
        if current_view_id != saved_view_id:
            xbmc.log(f"[Film Free JSON] Người dùng đã đổi View! Lưu Global ID mới: {current_view_id}", xbmc.LOGINFO)
            addon.setSetting('global_view_id', current_view_id)
            
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi cap_nhat_view: {e}", xbmc.LOGINFO)

def ep_view_toan_cuc():
    """
    Chạy cuối mỗi danh sách.
    Đọc Global ID và ÉP skin dùng nó.
    """
    try:
        addon = xbmcaddon.Addon()
        saved_view_id = addon.getSetting('global_view_id')
        
        if saved_view_id and saved_view_id.isdigit():
            # xbmc.log(f"[Film Free JSON] Ép Global View: {saved_view_id}", xbmc.LOGINFO)
            xbmc.executebuiltin(f"Container.SetViewMode({saved_view_id})")
            
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi ep_view: {e}", xbmc.LOGINFO)

def tao_hinh_placeholder(text, link=IMAGE_GENERATOR_URL):
    """
    (HÀM ĐÃ NÂNG CẤP - Gọi PHP Server/GD)
    Tạo một URL gọi đến script PHP (image.php) để render ảnh PNG
    với icon PNG + Text.
    """
    try:
        # 1. Kiểm tra xem người dùng đã cài đặt URL server chưa
        if not IMAGE_GENERATOR_URL or "myserver.com" in IMAGE_GENERATOR_URL:
            # Nếu chưa, dùng ảnh fallback
            xbmc.log("[Film Free JSON] Lỗi: IMAGE_GENERATOR_URL chưa được cài đặt.", xbmc.LOGERROR)
            return fallback_img 
            
        # 2. Xử lý text (phải mã hóa cho URL)
        encoded_text = parse.quote_plus(text.upper())

        # 3. Tạo URL (gọi script PHP của bạn)
        # (Script PHP sẽ tự tạo ảnh 400x600)
        final_url = f"{link}?text={encoded_text}"
        
        return final_url
        
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi tạo placeholder: {e}", xbmc.LOGINFO)
        return fallback_img # Trả về ảnh mặc định nếu lỗi

def lay_url_remote_config():
    """
    Lấy URL nguồn từ Settings. 
    Nếu Settings trống, trả về URL mặc định.
    """
    addon = xbmcaddon.Addon()
    # Lấy giá trị từ setting id="remote_source_url"
    setting_url = addon.getSetting("remote_source_url")
    
    # Kiểm tra nếu có giá trị và không phải khoảng trắng
    if setting_url and setting_url.strip():
        xbmc.log(f"[Film Free JSON] Sử dụng Remote URL từ Settings: {setting_url}", xbmc.LOGINFO)
        return setting_url.strip()
    
    # Nếu trống, dùng mặc định
    xbmc.log(f"[Film Free JSON] Settings trống, dùng URL mặc định.", xbmc.LOGINFO)
    return DEFAULT_REMOTE_URL

def tai_noi_dung_moi(ds_kenh, load_more):
    """
    (Hàm cửa ngõ - ĐÃ SỬA LỖI)
    Tải một trang danh sách và gọi hàm hiển thị MỚI.
    """
    xbmc.log("[Film Free JSON] tai_noi_dung_moi", xbmc.LOGINFO)
    try:
        # 1. Lấy tham số từ URL
        base_url_str = load_more.get('remote_data').get('url')
        page = '1' # mặc định trang 1
        
        paging = load_more.get('paging')
        page_key = paging.get('page_key')
        size_key = paging.get('size_key')
        
        # 2. Tạo URL đầy đủ để tải (với size=10 theo yêu cầu)
        url_parts = list(parse.urlsplit(base_url_str))
        query = dict(parse.parse_qsl(url_parts[3]))
        
        query[page_key] = page
        query[size_key] = 50  # <-- Home menu thì dùng 50
        
        url_parts[3] = parse.urlencode(query)
        url_to_load = parse.urlunsplit(url_parts)
        
        xbmc.log(f"[Film Free JSON] Đang tải URL phân trang: {url_to_load}", xbmc.LOGINFO)
        
        # 3. Tải dữ liệu
        # data = tai_du_lieu_json(url_to_load)
        # ds_kenh = data.get('channels')
        
        if not ds_kenh or not isinstance(ds_kenh, list):
            thong_bao("Film Free JSON", "Không có nội dung hoặc lỗi định dạng", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(addon_handle) # Phải kết thúc thư mục
            return

        # 4. GỌI HÀM HIỂN THỊ MỚI (KHÔNG TÁI SỬ DỤNG HÀM CŨ)
        hien_thi_kenh_theo_xem_them(
            ds_kenh, 
            url_to_load, 
            base_url_str, 
            load_more, home=True
        )
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi tai_noi_dung_moi: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi tai_noi_dung_moi: {e}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle) # Đảm bảo kết thúc nếu có lỗi

# ===== Xử lý router (điều hướng) =====
def main():
    try:
        
        action = args.get('action')
        # cap_nhat_view_toan_cuc()
        actions_from_home = [ 
            'open_source',
            'mo_nguon_xem_them',
            'set_nguon',
            'doi_nguon',
            'open_history_item',
            'play_history_episode',
            'open_channel_search'
        ]
        if action in actions_from_home or action is None:
            xbmc.log(f"[Film Free JSON] Không thao tác: {action}", xbmc.LOGINFO)
        else:
            # xbmc.log(f"[Film Free JSON] Thao tác: {action}", xbmc.LOGINFO)
            cap_nhat_view_toan_cuc()
        
        if action is None:
            hien_thi_nhom(); return

        if action == 'show_donate':
            show_donate_qr(); return

        if action == 'doi_nguon':
            hien_thi_ds_nguon_khac(); return
            
        if action == 'set_nguon':
            new_idx = int(args.get('new_idx', -1))
            dat_nguon_moi(new_idx); return

        if action == 'open_kodi_settings':
            open_kodi_settings(); return

        if action == 'open_group':
            g = int(args.get('g', -1))
            hien_thi_kenh_trong_nhom(g); return

        if action == 'open_channel':
            g = int(args.get('g', -1))
            i = int(args.get('i', -1))
            mo_kenh(g if g >= 0 else None, i); return

        if action == 'open_source':
            g = int(args.get('g', -1))
            i = int(args.get('i', -1))
            s = int(args.get('s', -1))
            mo_nguon(g if g >= 0 else None, i, s); return

        if action == 'play_direct':
            i = int(args.get('i', -1))
            g = int(args.get('g', -1)) if 'g' in args else None
            phat_truc_tiep(i, g); return

        if action == 'lich_su_xem':
            hien_thi_lich_su(); return

        if action == 'xoa_lich_su':
            ghi_lich_su([]); thong_bao("Film Free JSON", "Đã xóa toàn bộ lịch sử."); xbmc.executebuiltin("Container.Refresh"); return

        if action == 'play_from_history':
            idx = int(args.get('i', -1))
            phat_tu_lich_su(idx); return

        if action == 'open_history_item':
            idx = int(args.get('i', -1))
            mo_lich_su_item(idx); return

        if action == 'remove_history_item':
            idx = int(args.get('i', -1))
            xoa_muc_lich_su(idx); xbmc.executebuiltin("Container.Refresh"); return

        if action == 'play_history_episode':
            idx = int(args.get('i', -1))
            ep = int(args.get('e', -1))
            phat_tap_lich_su(idx, ep); return

        if action == 'search_input':
            # Mở hộp thoại nhập từ khóa tìm kiếm
            tu_khoa = xbmcgui.Dialog().input("Nhập từ khóa", type=xbmcgui.INPUT_ALPHANUM)
            if not tu_khoa: return
            # Mở luôn kết quả trang đầu
            mo_ket_qua_tim_kiem(tu_khoa, 1, KT_SEARCH); return

        if action == 'search_next':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            mo_ket_qua_tim_kiem(tu_khoa, trang, kich_thuoc); return

        if action == 'open_channel_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            mo_channel_tim_kiem(tu_khoa, trang, kich_thuoc, idx); return

        if action == 'open_source_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            src = int(args.get('src', '-1'))
            mo_source_tim_kiem(tu_khoa, trang, kich_thuoc, idx, src); return

        if action == 'play_direct_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            phat_truc_tiep_tim_kiem(tu_khoa, trang, kich_thuoc, idx); return

        if action == 'play_episode_search':
            tu_khoa = args.get('q') or ''
            trang = int(args.get('p', '1'))
            kich_thuoc = int(args.get('s', '50'))
            idx = int(args.get('idx', '-1'))
            src = int(args.get('src', '-1'))
            ep = int(args.get('ep', '-1'))
            phat_tap_tim_kiem(tu_khoa, trang, kich_thuoc, idx, src, ep); return
            
        if action == 'mo_xem_them':
            mo_xem_them(); return
            
        if action == 'tai_danh_sach_phan_trang':
            tai_danh_sach_phan_trang(); return
            
        if action == 'mo_kenh_xem_them':
            mo_kenh_xem_them(); return
        
        if action == 'mo_nguon_xem_them':
            mo_nguon_xem_them(); return

        # Mặc định: hiển thị danh sách nhóm
        hien_thi_nhom()
    except Exception as e:
        xbmc.log(f"[Film Free JSON] Lỗi router: {e}", xbmc.LOGINFO)
        thong_bao("Film Free JSON", f"Lỗi: {e}", xbmcgui.NOTIFICATION_ERROR)

if __name__ == "__main__":
    main()
