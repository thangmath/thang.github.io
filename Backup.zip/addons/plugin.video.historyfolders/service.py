import xbmc, os, json, xbmcvfs
from datetime import datetime

ADDON_ID = "plugin.video.historyfolders"
PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/")
HISTORY_FILE = os.path.join(PROFILE, "history.json")

if not xbmcvfs.exists(PROFILE):
    xbmcvfs.mkdirs(PROFILE)

def load_history():
    try:
        if xbmcvfs.exists(HISTORY_FILE):
            with open(HISTORY_FILE,"r",encoding="utf-8") as f:
                return json.load(f)
    except: pass
    return []

def save_history(history):
    try:
        with open(HISTORY_FILE,"w",encoding="utf-8") as f:
            json.dump(history,f,indent=2,ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"[HistoryFolders] save_history ERROR: {e}", xbmc.LOGERROR)

def add_path(path, label=None):
    if not path: return
    path = path.strip()
    folder_name = os.path.basename(path) or path
    label = label.strip() if label else folder_name
    timestamp = datetime.now().strftime("%d/%m/%Y - %H:%M")
    history = load_history()
    history = [h for h in history if h["path"] != path]
    history.insert(0, {"path": path, "label": label, "folder": folder_name, "time": timestamp})
    if len(history) > 50: history = history[:50]
    save_history(history)
    xbmc.log(f"[HistoryFolders] Saved path: {path} label: {label}", xbmc.LOGINFO)

def debug_labels():
    labels = {}
    try:
        for key in ["Container.FolderPath","ListItem.Path","ListItem.Label","Player.FilenameAndPath"]:
            val = xbmc.getInfoLabel(key)
            if val: labels[key] = val
    except: pass
    return labels

def is_from_history(path):
    return "?fromhistory=1" in path

class HistoryMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._last_saved = None

    def run_polling_once(self):
        labels = debug_labels()
        path = labels.get("Container.FolderPath") or labels.get("ListItem.Path")
        label = labels.get("ListItem.Label")
        if not path and "Player.FilenameAndPath" in labels:
            path = os.path.dirname(labels["Player.FilenameAndPath"])
        if not path or path == self._last_saved: return
        if is_from_history(path): return
        add_path(path,label)
        self._last_saved = path

monitor = HistoryMonitor()
while not monitor.abortRequested():
    try: monitor.run_polling_once()
    except: pass
    if monitor.waitForAbort(1): break
