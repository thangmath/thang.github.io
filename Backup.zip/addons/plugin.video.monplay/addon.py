from urllib.parse import urlencode, parse_qsl, unquote, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from json import loads, dumps
from functools import partial
from xbmcvfs import translatePath
from xbmcgui import ListItem, Dialog, INPUT_ALPHANUM
from sys import argv
from requests import Session
import re, os
addon_url = argv[0]
HANDLE = int(argv[1])
addon_name = Addon().getAddonInfo('name')
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
idsource = Addon().getSetting('idsource')
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
UA = 'Mozilla/5.0 (Linux; Android 16; Pixel 9 Pro Build/AP1A.241212) AppleWebKit/605.1.15 (KHTML, like Gecko) Dart/3.9 (dart:io) Chrome/140.0.0.0 Mobile Safari/605.1.15 EdgA/140.0.0.0'
def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    kwargs = {key: dumps(value) if isinstance(value, list) else value for key, value in kwargs.items()}
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url):
    with Session() as s:
        s.headers.update({'user-agent': UA,'referer': url})
        try:
            r = s.get(url, timeout=20)
        except:
            r = s.get(url, timeout=20, verify=False)
    r.encoding = 'utf-8'
    return r
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find(params_url):
    addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search', url=params_url, with_input=True)
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, m, 'timmon', url=params_url, key = m)
    endOfDirectory(HANDLE)
def timkiem(query, params_url):
    search_query = quote_plus(query)
    u = f'{params_url}{search_query}'
    list_monplay(u, 1)
def main():
    T = {
        'Rổ Bóng': 'https://providers.cotivi.online/robongz',
        'Chuối chiên TV': 'https://hxcv.site/chuoichien',
        'Văn Khánh TV' : 'https://hxcv.site/vankhanh',
        'Vạch Vôi TV' : 'https://hxcv.site/vachvoi',
        'Lương Sơn TV': 'https://hxcv.site/luongson',
        'Bún Chả TV' : 'https://hxcv.site/buncha',
        'Khán Đài A' : 'https://hxcv.site/khandaia',
        'Gà Vàng TV' : 'https://hxcv.site/gavang',
        'Xoilacz': 'https://providers.cotivi.online/xoilacz',
        'Cà khịa TV': 'https://providers.cotivi.online/cakhiaz',
        'Ra khơi TV': 'https://providers.cotivi.online/rakhoiz',
        'FPT Play': 'https://iptv.nhadai.org/v1',
        'VTVgo': 'https://vtvgo.4share.me',
        'Msky Live': 'https://mskytv.pro',
        'VOD Thể thao': 'https://soixamapi.vercel.app/api/vod?type=jsonIPTV',
        'KKPhim': 'https://media.hth4nh.eu.org/kkphim',
        'OPhim': 'https://media.hth4nh.eu.org/ophim',
        'Phim THVL': 'https://iptv.cameraddns.net'
        }
    for h in T:
        addDir(h, ICON, h, 'list_monplay', url = T[h], p=1)
    endOfDirectory(HANDLE)
def list_monplay(url, p, page_key=None, size_key=None):
    rx = getlink(url).json()
    search = rx.get('search')
    if search:
        addDir('Tìm kiếm', searchimg, 'Tìm kiếm', 'search', url=f"{search.get('url', '')}?{search.get('search_key', '')}=", with_input=False)
    if rx.get('sorts'):
        for s in rx['sorts']:
            textname = s['text']
            if s.get('url'):
                su = s['url']
                addDir(textname, ICON, textname, 'list_monplay', url=su, p=1)
            if s.get('value'):
                for v in s['value']:
                    stext = v['text']
                    fstext = stext if textname in stext else f'{textname} {stext}'
                    surl = v['url']
                    addDir(fstext, ICON, fstext, 'list_monplay', url=surl, p=1)
    numpage = int(p)
    load_more = rx.get('load_more')
    if load_more:
        u = load_more.get('remote_data', {}).get('url', url)
        paging = load_more.get('paging', {})
        pkey = page_key or paging.get('page_key', 'page')
        skey = size_key or paging.get('size_key', 'size')
        allkey = f'{pkey}={numpage}&{skey}=50'
        ux = f'{u}&{allkey}' if '?' in u else f'{u}?{allkey}'
        r = getlink(ux).json()
    else:
        u = url
        r = rx
    for key in ('channels', 'groups'):
        if r.get(key):
            process_items(r[key])
    if load_more:
        last_page = load_more.get('pageInfo', {}).get('last_page', 0)
        if last_page > numpage:
            next_page = str(numpage + 1)
            tenpage = f'Trang {next_page}'
            paging = r.get('load_more', {}).get('paging', {})
            addDir(tenpage, nextimg, tenpage, 'list_monplay', url=u, page_key=paging.get('page_key'), size_key=paging.get('size_key'), p=next_page)
    endOfDirectory(HANDLE)
def xu_ly_streams(r, name, description, anh):
    if r.get('remote_data'):
        rname = r['name']
        tenf = name if rname == name else f'{name} | {rname}'
        description = r.get('description', tenf)
        addDir(tenf, anh, description, 'remote_data', url=r['remote_data']['url'], name=tenf, description=tenf, anh=anh)
    if r.get('sources'):
        for a in r['sources']:
            host = a['name']
            for b in a['contents']:
                mua = b['name']
                if b.get('streams'):
                    for d in b['streams']:
                        description = d.get('description', name)
                        xu_ly_streams(d, name, description, anh)
    if r.get('stream_links'):
        tap = r.get('name')
        stream_links = r['stream_links']
        multi_server = len(stream_links) > 1
        for e in stream_links:
            tenserver = f"| {e['name']}" if multi_server else ''
            linkplay = e['url']
            parts = [name]
            if tap and name != tap:
                parts.append(f'| {tap}')
            if tenserver:
                parts.append(tenserver)
            fname = ' '.join(parts)
            ref = next((h['value'] for h in e.get('request_headers', []) if h.get('key', '').lower() == 'referer'), None)
            addDir(fname, anh, description, 'play', link=linkplay, ref=ref, is_folder=False)
    if r.get('channels'):
        process_items(r['channels'])
def process_items(items):
    for k in items:
        name = k['name']
        description = k.get('description', name)
        image = k.get('image', {}).get('url', ICON)
        xu_ly_streams(k, name, description, image)
def remote_data(url, name, description, anh):
    r = getlink(url).json()
    xu_ly_streams(r, name, description, anh)
    endOfDirectory(HANDLE)
def search(url, with_input):
    if with_input == 'True':
        query = Dialog().input(u'Nhập nội dung cần tìm ...', type=INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem(query, url)
        else:
            find(url)
    else:
        find(url)
def tfind(url):
    find(url)
def timmon(key, url):
    timkiem(key, url)
def play(link, sub=None, ref=None):
    with Session() as s:
        headers = {}
        hdr_parts = []
        if ref:
            headers['Referer'] = ref
            hdr_parts.append(f'Referer={ref}')
        s.headers.update(headers)
        try:
            r = s.get(link, timeout=20, stream=True)
        except:
            r = s.get(link, timeout=20, stream=True, verify=False)
            hdr_parts.append('verifypeer=false')
    hdr = '&'.join(hdr_parts) if hdr_parts else None
    ctype = r.headers.get('Content-Type', '')
    url = r.url
    if not 'mpegurl' in ctype and hdr:
        url = f'{url}|{hdr}'
    play_item = ListItem(offscreen=True, path=url)
    if 'mpegurl' in ctype:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        if hdr:
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    if sub:
        play_item.setSubtitles(loads(sub))
    setResolvedUrl(HANDLE, True, listitem=play_item)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'list_monplay': partial(list_monplay, params.get('url'), params.get('p'), params.get('page_key'), params.get('size_key')),
        'remote_data': partial(remote_data, params.get('url'), params.get('name'), params.get('description'), params.get('anh')),
        'search': partial(search, params.get('url'), params.get('with_input')),
        'timmon': partial(timmon, params.get('key'), params.get('url')),
        'play': partial(play, params.get('link'), params.get('sub'), params.get('ref'))
        }
    action_map.get(params.get('mode'), main)()
try:
    router(argv[2][1:])
except:
    pass