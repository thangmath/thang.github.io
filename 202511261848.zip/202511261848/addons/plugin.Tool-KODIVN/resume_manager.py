import json
import os
import subprocess
from datetime import datetime

resume_file = "resume_db.json"

# Lưu phim mới vào database
def save_resume(video_id, title, host):
    if os.path.exists(resume_file):
        db = json.load(open(resume_file))
    else:
        db = {}
    if video_id not in db:
        db[video_id] = {
            "title": title,
            "host": host,
            "last_position": 0,
            "last_played": ""
        }
    with open(resume_file, "w") as f:
        json.dump(db, f)

# Player hỗ trợ resume
def play_with_resume(video_id, url, player, resume_position):
    if player.lower() == "vlc":
        subprocess.call([
            "am", "start", "-n", "org.videolan.vlc/.StartActivity",
            "-d", url,
            "--es", "position", str(resume_position*1000)  # VLC tính ms
        ])
    elif player.lower() == "nova":
        subprocess.call([
            "am", "start", "-n", "com.nova.video/.MainActivity",
            "-d", url,
            "--es", "seek_position", str(resume_position)
        ])

# Player không hỗ trợ resume (Dune)
def play_dune_with_prompt(video_id, url, last_position):
    minutes = last_position // 60
    seconds = last_position % 60
    print(f"Bạn đã xem {minutes}:{seconds:02d} phút. Bắt đầu từ đây?")
    # user nhấn OK → mở link Dune
    subprocess.call(["am", "start", "-n", "com.dune/.MainActivity", "-d", url])

# Cập nhật vị trí khi thoát
def update_resume(video_id, current_position):
    if os.path.exists(resume_file):
        db = json.load(open(resume_file))
    else:
        db = {}
    if video_id in db:
        db[video_id]["last_position"] = current_position
        db[video_id]["last_played"] = datetime.now().isoformat()
    with open(resume_file, "w") as f:
        json.dump(db, f)
