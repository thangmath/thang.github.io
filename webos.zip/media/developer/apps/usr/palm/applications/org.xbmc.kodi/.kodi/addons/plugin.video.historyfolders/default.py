import xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs, json, os, sys
import re
from urllib.parse import unquote, parse_qs, urlparse

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HISTORY_FILE = os.path.join(PROFILE, "history.json")
#DEFAULT_ICON = "DefaultVideo.png"  # icon mặc định nếu không tìm thấy
DEFAULT_ICON = xbmcvfs.translatePath(os.path.join(ADDON.getAddonInfo('path'), "icon.png"))

def load_history():
    history_clean = []
    try:
        if xbmcvfs.exists(HISTORY_FILE):
            with open(HISTORY_FILE,"r",encoding="utf-8") as f:
                history = json.load(f)
            for h in history:
                folder = h.get("folder","")
                path = h.get("path","")
                # Ẩn folder rỗng, script://, library://video/, plugin://
                if folder in ("script://","", "plugin://") or path.startswith("library://video/") or path.startswith("plugin://plugin.video.historyfolders/"):
                    continue
                history_clean.append(h)
            # Tự động lưu lại file đã lọc
            with open(HISTORY_FILE,"w",encoding="utf-8") as f:
                json.dump(history_clean,f,indent=2,ensure_ascii=False)
    except: pass
    return history_clean

def get_display_label_and_icon(h, idx):
    label = h.get("label","")
    path = h.get("path","")
    folder = h.get("folder","")

    # Ẩn folder rỗng, script://, plugin://, library://video/
    if folder in ("script://","", "plugin://") or path.startswith("library://video/") or path.startswith("plugin://plugin.video.historyfolders/"):
        return None, None

    addon_name = ""
    folder_name = ""
    query = ""

    # Nếu label = ".."
    if label.strip() == "..":
        # Lấy addon rút gọn
        m = re.match(r'plugin://(plugin\.[^/]+)', path)
        if m:
            addon_name = m.group(1).replace("plugin.video.","").replace("plugin.","")

        # Tách path trước ?
        path_before_q = path.split("?")[0].rstrip("/")

        # Lấy folder gần cuối trước folder cuối
        parts = path_before_q.split("/")
        if len(parts) >= 2:
            folder_name = parts[-2]

        # Nếu path có query (URL params)
        if "?" in path:
            parsed_qs = parse_qs(urlparse(path).query)
            url_val = parsed_qs.get("url") or parsed_qs.get("video") or parsed_qs.get("id") or []
            if url_val:
                query = unquote(url_val[0])

        # Ghép label hiển thị
        if addon_name and folder_name and folder_name != addon_name:
            label = f"{addon_name} - {folder_name}"
        elif addon_name:
            label = addon_name
        elif folder_name:
            label = folder_name
        else:
            label = ".."
        if query:
            label += f" - {query}"

    # Nếu label = path root addon → hiển thị addon_name
    elif path.rstrip("/") == label.rstrip("/"):
        m = re.match(r'plugin://(plugin\.[^/]+)', path)
        if m:
            addon_name = m.group(1).replace("plugin.video.","").replace("plugin.","")
            label = addon_name

    # Nếu path có library_name → hiển thị tên library
    if "library_name=" in path:
        m = re.search(r'library_name=([^&]+)', path)
        if m:
            label = unquote(m.group(1))

    # Nếu path có video_name → hiển thị tên video
    if "video_name=" in path:
        m = re.search(r'video_name=([^&]+)', path)
        if m:
            label = unquote(m.group(1))

    # Lấy icon / thumb / poster / fanart
    icon = DEFAULT_ICON
    # 1. thử icon addon
    if addon_name:
        try:
            addon_obj = xbmcaddon.Addon(id=f"plugin.video.{addon_name}")
            addon_icon = addon_obj.getAddonInfo("icon")
            if addon_icon:
                icon = addon_icon
        except:
            pass
    # 2. thử thumb/poster/fanart từ history
    if icon == DEFAULT_ICON:
        for key in ("thumb","poster","fanart"):
            val = h.get(key)
            if val:
                icon = val
                break

    timestamp = h.get("time","")
    return f"[{idx}] {label} - ({timestamp})", icon

def list_history(handle):
    history = load_history()
    if not history:
        li = xbmcgui.ListItem(label="(Chưa có lịch sử nào)")
        li.setArt({'icon': DEFAULT_ICON, 'thumb': DEFAULT_ICON})
        xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for idx, h in enumerate(history, 1):
        label_display, icon = get_display_label_and_icon(h, idx)
        if not label_display:
            continue
        li = xbmcgui.ListItem(label=label_display)
        li.setPath(h['path'])
        li.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle, h['path'], li, isFolder=True)
    xbmcplugin.endOfDirectory(handle)

def router(argv):
    handle = int(argv[1])
    list_history(handle)

if __name__ == "__main__":
    router(sys.argv)
